import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api } from "@/convex/_generated/api";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useMutation, useQuery } from "convex/react";
import { useNavigate } from "react-router";
import { toast } from "sonner";
import {
  Atom,
  CalendarClock,
  CloudUpload,
  FlaskConical,
  Joystick,
  LogOut,
  Menu,
  Palette,
  Search,
  Trash2,
} from "lucide-react";
import {
  BOND_LABELS,
  COMPOUNDS,
  PLAYABLE_CATALOG,
  atomCount,
  bondMistakeMessage,
  dailyCompoundIndex,
  formulaTokens,
  guessBondType,
  molarMass,
  molecularGeometry,
  parseFormula,
  stringifyFormula,
  type BondType,
  type Environment,
} from "@/lib/chemistry";
import { PeriodicTable } from "@/components/PeriodicTable";
import { MoleculeViewer } from "@/components/MoleculeViewer";

// ── Modelo da câmara ────────────────────────────────────────────────────────
// As partículas vivem num painel absolutamente posicionado com coordenadas em
// porcentagem, então o layout sobrevive a redimensionamentos. Combinar =
// arrastar uma partícula sobre a outra.

interface Particle {
  id: string;
  symbol: string; // rótulo exibido (símbolo do elemento ou fórmula)
  formula: string; // composição canônica
  x: number; // % da largura do painel
  y: number; // % da altura do painel
  dragging?: boolean;
}

let particleSeq = 0;
const nextId = () => `p${++particleSeq}`;
const clampPct = (v: number) => Math.min(96, Math.max(4, v));

const ACCENT_SWATCHES = [
  "#00ff66", "#00d0ff", "#ff0055", "#ffd700", "#9d00ff", "#ff8800", "#ffffff", "#ff66cc", "#0022ff",
];
const SHAPE_SWATCHES: Array<{ label: string; value: string }> = [
  { label: "Redondo", value: "50%" },
  { label: "Quadrado suave", value: "10px" },
  { label: "Quadrado", value: "0%" },
];

type Mode = "mission" | "free";

export default function Dashboard() {
  const { signOut } = useAuth();
  const navigate = useNavigate();

  // ── Progresso + aparência + sessão (persistidos no Convex) ────────────────
  const progress = useQuery(api.progress.getProgress);
  const awardXp = useMutation(api.progress.awardXp);
  const setAppearance = useMutation(api.progress.setAppearance);
  const saveSession = useMutation(api.progress.saveSession);

  const appearance = progress?.appearance ?? { accentColor: "#00ff66", particleShape: "50%" };
  // Preferências locais com fallback: só assumem o valor salvo enquanto o
  // jogador não escolheu nada nesta sessão (evita re-render em cascata via
  // useEffect na chegada da query).
  const [chosenAccent, setChosenAccent] = useState<string | null>(null);
  const [chosenShape, setChosenShape] = useState<string | null>(null);
  const accent = chosenAccent ?? appearance.accentColor;
  const shape = chosenShape ?? appearance.particleShape;

  const persistAppearance = (next: { accentColor: string; particleShape: string }) => {
    setAppearance(next).catch(() => toast.error("Não foi possível salvar seu tema."));
  };

  // ── Estado da missão ─────────────────────────────────────────────────────
  const [mode, setMode] = useState<Mode>("mission");
  const [compoundIndex, setCompoundIndex] = useState(() => dailyCompoundIndex(new Date()));
  const [isDaily, setIsDaily] = useState(true);
  // Guarda até a sessão salva no banco chegar; depois, hidrata o estado uma vez.
  const hydratedRef = useRef(false);
  const [hydrated, setHydrated] = useState(false);
  const compound = COMPOUNDS[compoundIndex];
  const goalFormula = useMemo(
    () => stringifyFormula(parseFormula(compound.formula)),
    [compound],
  );
  const goalTokens = useMemo(() => formulaTokens(goalFormula), [goalFormula]);

  const [bondAnswer, setBondAnswer] = useState<BondType | null>(null);
  const [bondHint, setBondHint] = useState<string | null>(null);
  const [env, setEnv] = useState<Environment>({
    temperature: 25,
    pressure: 1,
    catalyst: "",
    electricity: false,
    radiation: false,
  });

  const [particles, setParticles] = useState<Particle[]>([]);
  const [successOpen, setSuccessOpen] = useState(false);
  const [lastGained, setLastGained] = useState(0);
  const [leveledTo, setLeveledTo] = useState<number | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [hintOpen, setHintOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  /** Toast de condição inadequada exibido uma vez por fórmula correta. */
  const warnedFormula = useRef<string | null>(null);
  /** Brilho momentâneo da lâmpada quando o jogador tenta misturar sem condições adequadas. */
  const [bulbPulse, setBulbPulse] = useState(false);
  const bulbPulseTimer = useRef<number | null>(null);
  const fireBulbPulse = useCallback(() => {
    setBulbPulse(true);
    if (bulbPulseTimer.current !== null) window.clearTimeout(bulbPulseTimer.current);
    bulbPulseTimer.current = window.setTimeout(() => setBulbPulse(false), 1600);
  }, []);

  const boardRef = useRef<HTMLDivElement>(null);
  const dragState = useRef<{ id: string; dx: number; dy: number } | null>(null);
  const awardLock = useRef(false);

  const freeMode = mode === "free";
  const envOK = freeMode || compound.check(env);
  const bondOK = freeMode || bondAnswer === compound.bond;
  const mixLocked = !freeMode && !bondOK; // misturar fica bloqueado até acertar a ligação

  // ── Fotólise: a luz quebra as moléculas em seus elementos ────────────────
  const [photolysis, setPhotolysis] = useState(false);
  const photolysisTimer = useRef<number | null>(null);
  const firePhotolysis = useCallback(() => {
    setPhotolysis(true);
    if (photolysisTimer.current !== null) window.clearTimeout(photolysisTimer.current);
    photolysisTimer.current = window.setTimeout(() => setPhotolysis(false), 1800);
  }, []);

  const crackMolecules = useCallback(() => {
    setParticles((prev) => {
      const cracked: Particle[] = [];
      for (const p of prev) {
        const comps = parseFormula(p.formula);
        const keys = Object.keys(comps);
        if (keys.length === 1 && comps[keys[0]] === 1) {
          cracked.push(p);
          continue;
        }
        const flat: string[] = [];
        for (const [sym, n] of Object.entries(comps)) {
          for (let i = 0; i < n; i++) flat.push(sym);
        }
        flat.forEach((sym, i) => {
          cracked.push({
            id: nextId(),
            symbol: sym,
            formula: sym,
            x: clampPct(p.x + (i - (flat.length - 1) / 2) * 7),
            y: clampPct(p.y + (Math.random() * 10 - 5)),
          });
        });
      }
      return cracked;
    });
  }, []);

  // Botão de fotólise: dispara um pulso de luz que decompõe as moléculas do
  // painel em seus elementos (moléculas de um único átomo permanecem).
  const triggerPhotolysis = useCallback(() => {
    if (particles.length === 0) {
      toast.info("Nada para decompor — crie elementos no catálogo primeiro.");
      return;
    }
    const hasMolecules = particles.some((p) => atomCount(p.formula) > 1);
    firePhotolysis();
    if (hasMolecules) {
      crackMolecules();
      toast.success("☀️ Fotólise! A luz quebrou as moléculas em elementos.");
    } else {
      toast.info("A luz brilhou, mas não há moléculas para decompor.");
    }
  }, [particles, crackMolecules, firePhotolysis]);

  // ── Detecção de síntese (somente no modo missão) ─────────────────────────
  // Reativa: no instante em que uma partícula no painel casa com a fórmula do
  // objetivo E as condições permitem, concede XP.
  useEffect(() => {
    if (!hydrated || freeMode || !bondOK || successOpen || awardLock.current) return;
    const match = particles.find((p) => p.formula === goalFormula);
    if (!match || !envOK) return;

    awardLock.current = true;
    awardXp({ formula: goalFormula, isDailyChallenge: isDaily })
      .then((res) => {
        setLastGained(res.gained);
        setLeveledTo(res.leveledUpTo ?? null);
        setSuccessOpen(true);
        if (res.leveledUpTo) {
          toast.success(`Subiu de nível! Você alcançou o nível ${res.leveledUpTo}.`);
        }
      })
      .catch(() => {
        awardLock.current = false;
        toast.error("Não foi possível salvar seu progresso.");
      });
  }, [
    hydrated,
    particles,
    goalFormula,
    envOK,
    bondOK,
    successOpen,
    isDaily,
    freeMode,
    awardXp,
  ]);

  // ── Hidratação da sessão: restaura o laboratório exatamente como ficou ──
  // Roda uma única vez, quando a query do banco chega pela primeira vez.
  // O setState roda num microtask para evitar cascata de render síncrona.
  useEffect(() => {
    if (hydratedRef.current || progress === undefined) return;
    hydratedRef.current = true;

    const t = window.setTimeout(() => {
      const saved = progress?.session;
      if (!saved) {
        setHydrated(true);
        return;
      }

      // Índices fora do catálogo (ex.: catálogo mudou entre sessões) caem
      // para o desafio diário do dia.
      const idx =
        saved.compoundIndex >= 0 && saved.compoundIndex < COMPOUNDS.length
          ? saved.compoundIndex
          : dailyCompoundIndex(new Date());
      setCompoundIndex(idx);
      setIsDaily(saved.isDaily);
      setMode(saved.mode);
      setBondAnswer((saved.bondAnswer as BondType | undefined) ?? null);
      setEnv(saved.env);
      setParticles(
        saved.particles.map((p) => ({ ...p, id: nextId(), dragging: false })),
      );
      // Se a sessão restaurada já contém a fórmula do objetivo nas condições
      // certas, bloqueia a re-compensação automática de XP: o jogador precisa
      // mexer na mesa (ou trocar de missão) para sintetizar de novo.
      const restoredCompound = COMPOUNDS[idx];
      const restoredBondOk = saved.mode === "free" || saved.bondAnswer === restoredCompound.bond;
      const restoredEnvOk =
        saved.mode === "free" || restoredCompound.check(saved.env);
      if (
        restoredBondOk &&
        restoredEnvOk &&
        saved.particles.some((p) => p.formula === restoredCompound.formula)
      ) {
        awardLock.current = true;
      }
      setHydrated(true);
      toast.info("Bem-vindo de volta! Seu laboratório foi restaurado.");
    }, 0);
    return () => window.clearTimeout(t);
  }, [progress]);

  // ── Autosave da sessão: todo estado do jogo vai para o banco ────────────
  // Debounce de 800 ms para não disparar uma mutation a cada frame de arrasto.
  useEffect(() => {
    if (!hydrated || progress === undefined) return;
    const t = window.setTimeout(() => {
      saveSession({
        mode,
        compoundIndex,
        isDaily,
        bondAnswer: bondAnswer ?? undefined,
        env: {
          temperature: env.temperature,
          pressure: env.pressure,
          catalyst: env.catalyst,
          electricity: env.electricity,
          radiation: env.radiation,
        },
        particles: particles.map((p) => ({
          symbol: p.symbol,
          formula: p.formula,
          x: p.x,
          y: p.y,
        })),
      }).catch(() => {}); // silencioso: salvar sessão é best-effort
    }, 800);
    return () => window.clearTimeout(t);
  }, [
    hydrated,
    progress,
    saveSession,
    mode,
    compoundIndex,
    isDaily,
    bondAnswer,
    env,
    particles,
  ]);

  // ── Lâmpada: brilha quando a mistura não se junta por causa das condições ─
  // Derivado durante o render (sem setState em efeito): acende quando a
  // fórmula-alvo está no painel mas as condições não são adequadas.
  const formulaOnBoard = !freeMode && particles.some((p) => p.formula === goalFormula);
  const conditionsBlock = !freeMode && formulaOnBoard && !envOK;
  useEffect(() => {
    if (!conditionsBlock || warnedFormula.current === goalFormula) return;
    warnedFormula.current = goalFormula;
    toast.warning("Fórmula certa — condições erradas!", {
      description: compound.hint,
    });
  }, [conditionsBlock, goalFormula, compound.hint]);

  // ── Criar elementos ──────────────────────────────────────────────────────
  const spawnElement = useCallback(
    (symbol: string) => {
      if (mixLocked) {
        toast.error("Escolha o tipo de ligação primeiro!", {
          description: "Declare como os átomos deste composto se conectam antes de misturar.",
        });
        return;
      }
      setParticles((prev) =>
        prev.length >= 24
          ? prev
          : [
              ...prev,
              {
                id: nextId(),
                symbol,
                formula: symbol,
                x: 25 + Math.random() * 50,
                y: 25 + Math.random() * 45,
              },
            ],
      );
    },
    [mixLocked],
  );

  // ── Arrastar e soltar ────────────────────────────────────────────────────
  const onPointerDown = (e: React.PointerEvent, p: Particle) => {
    if (mixLocked) return;
    e.preventDefault();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    const rect = boardRef.current?.getBoundingClientRect();
    if (!rect) return;
    dragState.current = {
      id: p.id,
      dx: ((e.clientX - rect.left) / rect.width) * 100 - p.x,
      dy: ((e.clientY - rect.top) / rect.height) * 100 - p.y,
    };
    setParticles((prev) =>
      prev.map((q) => (q.id === p.id ? { ...q, dragging: true } : q)),
    );
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const ds = dragState.current;
    const rect = boardRef.current?.getBoundingClientRect();
    if (!ds || !rect) return;
    const x = clampPct(((e.clientX - rect.left) / rect.width) * 100 - ds.dx);
    const y = clampPct(((e.clientY - rect.top) / rect.height) * 100 - ds.dy);
    setParticles((prev) => prev.map((q) => (q.id === ds.id ? { ...q, x, y } : q)));
  };

  const onPointerUp = () => {
    const ds = dragState.current;
    dragState.current = null;
    if (!ds) return;
    setParticles((prev) => {
      const dropped = prev.find((p) => p.id === ds.id);
      if (!dropped) return prev;

      const release = () =>
        prev.map((q) => (q.id === ds.id ? { ...q, dragging: false } : q));

      // ── Bloqueio por condições: sem condições adequadas, os elementos NÃO
      // se juntam. A lâmpada brilha para sinalizar o porquê.
      if (!freeMode && (!bondOK || !envOK)) {
        fireBulbPulse();
        return release();
      }

      // Encontra a partícula mais próxima dentro do raio de fusão (em px).
      const rect = boardRef.current?.getBoundingClientRect();
      if (!rect) return release();
      const px = rect.left + (dropped.x / 100) * rect.width;
      const py = rect.top + (dropped.y / 100) * rect.height;

      let target: Particle | null = null;
      let best = 72;
      for (const q of prev) {
        if (q.id === dropped.id) continue;
        const qx = rect.left + (q.x / 100) * rect.width;
        const qy = rect.top + (q.y / 100) * rect.height;
        const dist = Math.hypot(px - qx, py - qy);
        if (dist < best) {
          best = dist;
          target = q;
        }
      }
      if (!target) return release();

      // Combina as composições: arrastada + alvo -> fórmula combinada.
      const merged: Record<string, number> = { ...parseFormula(dropped.formula) };
      for (const [sym, n] of Object.entries(parseFormula(target.formula))) {
        merged[sym] = (merged[sym] ?? 0) + n;
      }
      const resultFormula = stringifyFormula(merged);

      const midX = (dropped.x + target.x) / 2;
      const midY = (dropped.y + target.y) / 2;
      return [
        ...prev.filter((p) => p.id !== dropped.id && p.id !== target.id),
        { id: nextId(), symbol: resultFormula, formula: resultFormula, x: midX, y: midY },
      ];
    });
  };

  const clearBoard = () => setParticles([]);

  // ── Feedback químico (GPE / GM ou retículo) ──────────────────────────────
  // Sempre chamado (ordem estável de hooks): no modo livre, a geometria é da
  // soma de tudo no painel; no modo missão, do objetivo atual.
  const feedbackFormula = useMemo(() => {
    if (!freeMode) return goalFormula;
    const merged: Record<string, number> = {};
    for (const p of particles) {
      for (const [sym, n] of Object.entries(parseFormula(p.formula))) {
        merged[sym] = (merged[sym] ?? 0) + n;
      }
    }
    return Object.keys(merged).length > 0 ? stringifyFormula(merged) : "";
  }, [freeMode, goalFormula, particles]);

  const feedbackBond: BondType = freeMode
    ? feedbackFormula
      ? guessBondType(feedbackFormula)
      : "covalent"
    : (bondAnswer ?? compound.bond);

  const geometry = useMemo(
    () => (feedbackFormula ? molecularGeometry(feedbackFormula, feedbackBond) : null),
    [feedbackFormula, feedbackBond],
  );

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const applyAccent = (color: string) => {
    setChosenAccent(color);
    persistAppearance({ accentColor: color, particleShape: shape });
  };
  const applyShape = (value: string) => {
    setChosenShape(value);
    persistAppearance({ accentColor: accent, particleShape: value });
  };

  const switchMode = (next: Mode) => {
    setParticles([]);
    setSuccessOpen(false);
    setBulbPulse(false);
    setBondAnswer(null);
    setBondHint(null);
    warnedFormula.current = null;
    awardLock.current = false;
    setMode(next);
    if (next === "free") {
      toast.info("Modo livre ativado — misture à vontade!", {
        description: "O painel de feedback identifica o que você criou e explica a geometria.",
      });
    }
  };

  return (
    <div
      className="cc-root relative flex h-screen w-full overflow-hidden"
      style={
        {
          "--cc-accent": accent,
          "--cc-particle-shape": shape,
        } as React.CSSProperties
      }
    >
      {/* ── Barra lateral: catálogo + controles do ambiente ────────────────── */}
      <aside
        className={`absolute inset-y-0 left-0 z-40 flex w-72 flex-col border-r border-[var(--cc-border)] bg-[var(--cc-panel)] transition-transform duration-200 lg:static lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="border-b border-[var(--cc-border)] bg-[var(--cc-panel-raised)] p-4">
          <div className="flex items-center gap-2">
            <FlaskConical className="size-4 text-[var(--cc-accent)]" />
            <span className="text-sm font-bold tracking-widest text-[var(--cc-accent)]">
              CHEMCRAFT
            </span>
          </div>
        </div>

        <ScrollArea className="cc-scroll min-h-0 flex-1">
          <div className="p-4">
            <CatalogList onPick={spawnElement} highlight={goalTokens.map(([s]) => s)} />
          </div>
        </ScrollArea>

        <div className="border-t border-[var(--cc-border)] bg-[var(--cc-panel-tools)] p-4">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label className="mb-1 block text-[9px] uppercase tracking-wider text-[var(--cc-text-muted)]">
                Temp. (°C)
              </Label>
              <Input
                type="number"
                className="cc-field h-8 text-xs"
                value={env.temperature}
                onChange={(e) =>
                  setEnv((prev) => ({ ...prev, temperature: Number(e.target.value) || 0 }))
                }
              />
            </div>
            <div>
              <Label className="mb-1 block text-[9px] uppercase tracking-wider text-[var(--cc-text-muted)]">
                Pressão (atm)
              </Label>
              <Input
                type="number"
                className="cc-field h-8 text-xs"
                value={env.pressure}
                onChange={(e) =>
                  setEnv((prev) => ({ ...prev, pressure: Number(e.target.value) || 0 }))
                }
              />
            </div>
          </div>
          <Label className="mb-1 mt-3 block text-[9px] uppercase tracking-wider text-[var(--cc-text-muted)]">
            Catalisador
          </Label>
          <Select
            value={env.catalyst || "none"}
            onValueChange={(v) => setEnv((prev) => ({ ...prev, catalyst: v === "none" ? "" : v }))}
          >
            <SelectTrigger className="cc-field h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="cc-root border-[var(--cc-border)] bg-[var(--cc-panel)] text-[#eee]">
              <SelectItem value="none">Nenhum</SelectItem>
              <SelectItem value="Fe">Ferro (Fe)</SelectItem>
              <SelectItem value="Pt">Platina (Pt)</SelectItem>
              <SelectItem value="Ni">Níquel (Ni)</SelectItem>
            </SelectContent>
          </Select>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              className={`cc-toggle flex-1 py-2 text-xs font-medium ${env.electricity ? "active" : ""}`}
              onClick={() => setEnv((prev) => ({ ...prev, electricity: !prev.electricity }))}
            >
              ⚡ Eletricidade
            </button>
            <button
              type="button"
              className={`cc-toggle flex-1 py-2 text-xs font-medium ${env.radiation ? "active" : ""}`}
              onClick={() => setEnv((prev) => ({ ...prev, radiation: !prev.radiation }))}
            >
              ☢️ Radiação
            </button>
          </div>
        </div>
      </aside>

      {sidebarOpen && (
        <div
          className="absolute inset-0 z-30 bg-black/60 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* ── Área de trabalho ───────────────────────────────────────────────── */}
      <div className="relative flex flex-1 flex-col overflow-hidden">
        {/* Barra superior */}
        <header className="z-20 flex items-center justify-between gap-2 border-b border-[var(--cc-border)] bg-black/40 px-4 py-3">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="size-7 text-[#eee] lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="size-4" />
            </Button>
            <div className="flex overflow-hidden rounded-full border border-[var(--cc-border)] text-xs font-bold">
              <button
                type="button"
                onClick={() => switchMode("mission")}
                className={`px-3 py-1.5 transition ${
                  mode === "mission"
                    ? "bg-[var(--cc-accent-10)] text-[var(--cc-accent)]"
                    : "text-[#888] hover:text-[#ccc]"
                }`}
              >
                🎯 Missão
              </button>
              <button
                type="button"
                onClick={() => switchMode("free")}
                className={`px-3 py-1.5 transition ${
                  mode === "free"
                    ? "bg-[var(--cc-accent-10)] text-[var(--cc-accent)]"
                    : "text-[#888] hover:text-[#ccc]"
                }`}
              >
                🧪 Modo livre
              </button>
            </div>
            {!freeMode && (
              <>
                <span className="cc-chip px-3 py-1 text-xs font-bold whitespace-nowrap">
                  Nv {progress?.level ?? 1}
                </span>
                <div className="hidden items-center gap-2 sm:flex">
                  <Progress
                    value={progress ? (progress.xp / Math.max(progress.xpRequired, 1)) * 100 : 0}
                    className="h-2 w-20 bg-[var(--cc-element)] sm:w-28"
                  />
                  <span className="text-[10px] whitespace-nowrap text-[var(--cc-text-muted)]">
                    {progress?.xp ?? 0}/{progress?.xpRequired ?? 100} XP
                  </span>
                </div>
              </>
            )}
            {hydrated && (
              <span
                className="hidden items-center gap-1 text-[10px] whitespace-nowrap text-[var(--cc-text-muted)] md:flex"
                title="Tudo no seu laboratório é salvo automaticamente na nuvem"
              >
                <CloudUpload className="size-3.5 text-[var(--cc-accent)] opacity-70" />
                salvo na nuvem
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {!freeMode && (
              <Button
                variant="outline"
                size="sm"
                className="cc-element h-8 border-[var(--cc-border)] bg-transparent px-2 text-xs text-[#eee] sm:px-3"
                onClick={() => {
                  setParticles([]);
                  setCompoundIndex(dailyCompoundIndex(new Date()));
                  setIsDaily(true);
                  awardLock.current = false;
                  warnedFormula.current = null;
                  toast.info("Desafio diário carregado — boa sorte!");
                }}
              >
                <CalendarClock className="size-3.5 text-[#ffd700]" />
                <span className="hidden sm:inline">Diário</span>
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              className="cc-element h-8 border-[var(--cc-border)] bg-transparent px-2 text-xs text-[#eee] sm:px-3"
              onClick={() => setSettingsOpen(true)}
            >
              <Palette className="size-3.5" />
              <span className="hidden sm:inline">Personalizar</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="cc-element h-8 border-[var(--cc-border)] bg-transparent px-2 text-xs text-[#eee] sm:px-3"
              onClick={handleSignOut}
            >
              <LogOut className="size-3.5" />
              <span className="hidden sm:inline">Sair</span>
            </Button>
          </div>
        </header>

        {/* Câmara */}
        <div className="relative flex-1 overflow-hidden">
          {/* Anel de pressão */}
          <div
            className="pointer-events-none absolute inset-4 z-0 rounded-xl border-4 border-[var(--cc-accent-10)] transition-transform duration-500"
            style={{ transform: `scale(${Math.max(0.3, 1 - env.pressure * 0.015)})` }}
          />
          {/* Tinta de temperatura */}
          <div
            className="pointer-events-none absolute inset-0 z-0 transition-colors duration-500"
            style={{
              backgroundColor: `rgba(255, 0, 0, ${Math.min(env.temperature / 1000, 0.5)})`,
            }}
          />
          {/* Tinta de radiação */}
          <div
            className="pointer-events-none absolute inset-0 z-0 transition-colors duration-500"
            style={{
              backgroundColor: env.radiation ? "rgba(128, 0, 128, 0.3)" : "transparent",
            }}
          />

          {/* Painel da missão */}
          {!freeMode && (
            <div className="pointer-events-none absolute left-4 top-4 z-20 max-w-[240px] rounded-lg border-l-4 border-[var(--cc-accent)] bg-black/80 p-3 backdrop-blur">
              <div className="text-[10px] uppercase tracking-wider text-[#aaa]">
                {isDaily ? "Desafio diário" : "Objetivo"}
              </div>
              <div className="mt-0.5 flex items-center gap-2">
                <span className="text-xl">{compound.emoji}</span>
                <strong className="text-xl text-[var(--cc-accent)]">{goalFormula}</strong>
              </div>
              <div className="mt-1 text-xs text-[#ccc]">{compound.name}</div>
            </div>
          )}
          {freeMode && (
            <div className="pointer-events-none absolute left-4 top-4 z-20 max-w-[240px] rounded-lg border-l-4 border-[var(--cc-accent)] bg-black/80 p-3 backdrop-blur">
              <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-[#aaa]">
                <Joystick className="size-3" />
                Modo livre
              </div>
              <div className="mt-1 text-xs text-[#ccc]">
                Misture qualquer elemento e descubra o que você criou.
              </div>
            </div>
          )}

          {/* Botão de fotólise: topo central, ao lado do painel da missão. */}
          <div className="absolute left-1/2 top-4 z-20 -translate-x-1/2">
            <button
              type="button"
              onClick={triggerPhotolysis}
              className={`flex items-center gap-2 rounded-full border px-4 py-2 text-xs font-bold backdrop-blur transition-all ${
                photolysis
                  ? "border-amber-300 bg-amber-300 text-black shadow-[0_0_28px_#fde68a]"
                  : "border-[var(--cc-border)] bg-black/80 text-[#ccc] hover:border-amber-300 hover:text-amber-200"
              }`}
              title="Fotólise: um pulso de luz decompõe as moléculas do painel"
            >
              ☀️ Fotólise
            </button>
            {photolysis && (
              <div className="cc-fade-in pointer-events-none absolute left-1/2 top-full mt-2 w-64 -translate-x-1/2 rounded-lg border border-amber-300/50 bg-black/95 p-3 text-center text-xs leading-5 text-amber-100 backdrop-blur">
                ☀️ Fotólise — a luz está decompondo as moléculas!
              </div>
            )}
          </div>

          {/* Lâmpada de dica: acende quando a fórmula está no painel mas as
              condições não são adequadas, e pulsa quando uma tentativa de
              mistura é bloqueada. */}
          <div className="absolute right-4 top-4 z-20 flex flex-col items-end gap-2">
            <button
              type="button"
              onClick={() => setHintOpen((v) => !v)}
              className={`flex size-11 items-center justify-center rounded-full text-2xl transition-all ${
                conditionsBlock || bulbPulse || hintOpen
                  ? "border-[var(--cc-accent)] bg-[var(--cc-accent)] shadow-[0_0_28px_var(--cc-accent)]"
                  : "border border-[var(--cc-border)] bg-[var(--cc-element)]"
              } ${conditionsBlock && !bulbPulse ? "cc-float" : ""}`}
              title="Dica"
            >
              💡
            </button>
            {hintOpen && (
              <div className="cc-fade-in w-56 rounded-lg border border-[var(--cc-border)] bg-black/95 p-3 text-xs leading-5 text-[#ccc] backdrop-blur">
                {freeMode
                  ? "No modo livre não há objetivo: combine os elementos como quiser e observe o painel de feedback químico para aprender a geometria e o tipo de ligação do que você criou."
                  : conditionsBlock
                    ? "A fórmula está montada, mas as condições não são adequadas! Ajuste temperatura, pressão, catalisador, eletricidade ou radiação antes de tentar de novo."
                    : compound.hint}
              </div>
            )}
          </div>

          {/* Seletor de ligação */}
          {!freeMode && (
            <div className="absolute bottom-4 left-1/2 z-20 w-[min(540px,calc(100%-2rem))] -translate-x-1/2 rounded-xl border border-[var(--cc-border)] bg-black/85 p-3 backdrop-blur">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-[9px] uppercase tracking-wider text-[var(--cc-text-muted)]">
                    Etapa 1 — declare o tipo de ligação
                  </div>
                  <div className="text-xs text-[#ccc]">
                    Como os átomos de {goalFormula} se conectam?
                  </div>
                </div>
                {bondOK && (
                  <span className="rounded bg-[var(--cc-accent-10)] px-2 py-1 text-[10px] font-bold whitespace-nowrap text-[var(--cc-accent)]">
                    ✓ {BOND_LABELS[compound.bond]}
                  </span>
                )}
              </div>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {(Object.keys(BOND_LABELS) as BondType[]).map((bond) => (
                  <button
                    key={bond}
                    type="button"
                    className={`cc-toggle py-2 text-xs font-semibold ${bondAnswer === bond ? "active" : ""}`}
                    onClick={() => {
                      setBondAnswer(bond);
                      if (bond === compound.bond) {
                        setBondHint(null);
                        toast.success(`Ligação ${BOND_LABELS[bond].toLowerCase()} confirmada — comece a misturar!`);
                      } else {
                        setBondHint(bondMistakeMessage(compound, bond));
                      }
                    }}
                  >
                    {BOND_LABELS[bond]}
                  </button>
                ))}
              </div>
              {bondHint && (
                <p className="cc-fade-in mt-2 rounded border border-[var(--cc-danger)]/40 bg-[var(--cc-danger)]/10 p-2 text-[11px] leading-5 text-[#ffb4a1]">
                  {bondHint}
                </p>
              )}
            </div>
          )}

          {/* Catalisador ativo */}
          {env.catalyst && (
            <div className="absolute bottom-4 left-4 z-20 hidden rounded-lg border-l-4 border-[var(--cc-accent)] bg-black/80 px-3 py-1.5 text-xs font-bold backdrop-blur md:block">
              Catalisador: {env.catalyst}
            </div>
          )}

          {/* Painel de feedback químico */}
          <div className="absolute bottom-4 right-4 z-20 hidden w-72 rounded-xl border border-[var(--cc-border)] bg-black/85 p-4 backdrop-blur xl:block">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-[var(--cc-text-muted)]">
              <Atom className="size-3.5 text-[var(--cc-accent)]" />
              Feedback químico
            </div>
            {geometry && (freeMode || bondOK) ? (
              <div className="mt-2 space-y-1.5 text-xs leading-5">
                {geometry.lattice ? (
                  <div>
                    <span className="font-bold text-[var(--cc-accent)]">
                      {feedbackBond === "ionic" ? "Retículo cristalino" : "Nuvem de elétrons"}:
                    </span>{" "}
                    <span className="text-[#ccc]">{geometry.lattice}</span>
                  </div>
                ) : (
                  <>
                    <div>
                      <span className="font-bold text-[var(--cc-accent)]">GPE:</span>{" "}
                      <span className="text-[#ccc]">{geometry.gpe}</span>
                    </div>
                    <div>
                      <span className="font-bold text-[var(--cc-accent)]">GM:</span>{" "}
                      <span className="text-[#ccc]">{geometry.gm}</span>
                    </div>
                    <div>
                      <span className="font-bold text-[var(--cc-accent)]">Ângulo:</span>{" "}
                      <span className="text-[#ccc]">{geometry.angle}</span>
                    </div>
                    <div className="text-[10px] text-[var(--cc-text-muted)]">
                      Átomo central: {geometry.noCenter ? "nenhum (diatômica)" : geometry.central} ·{" "}
                      {geometry.domains} domínio{geometry.domains === 1 ? "" : "s"}
                      {geometry.lonePairs > 0
                        ? ` (${geometry.lonePairs} par${geometry.lonePairs > 1 ? "es" : ""} isolado${geometry.lonePairs > 1 ? "s" : ""})`
                        : ""}
                    </div>
                  </>
                )}
                <div className="text-[10px] text-[var(--cc-text-muted)]">
                  Ligação: {BOND_LABELS[feedbackBond].toLowerCase()}
                </div>
              </div>
            ) : (
              <p className="mt-2 text-xs leading-5 text-[var(--cc-text-muted)]">
                {freeMode
                  ? "Misture elementos no painel para ver a análise aqui."
                  : "Declare o tipo de ligação correto para liberar a análise da geometria."}
              </p>
            )}
          </div>

          {/* Painel arrastável com o desenho 3D da molécula/estrutura. */}
          {!freeMode && geometry && (
            <MoleculePanel geometry={geometry} bondLabel={feedbackBond} />
          )}

          {/* Painel de arrastar */}
          <div
            ref={boardRef}
            className="absolute inset-0 z-10"
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
          >
            {particles.map((p) => (
              <div
                key={p.id}
                onPointerDown={(e) => onPointerDown(e, p)}
                onDoubleClick={() => setParticles((prev) => prev.filter((q) => q.id !== p.id))}
                className={[
                  "cc-particle absolute z-50 flex items-center justify-center font-bold",
                  p.dragging ? "dragging" : "",
                  env.electricity ? "cc-electrified" : "",
                  atomCount(p.formula) > 1 ? "cc-molecule" : "",
                ].join(" ")}
                style={{
                  left: `${p.x}%`,
                  top: `${p.y}%`,
                  transform: "translate(-50%, -50%)",
                  minWidth: 50,
                  height: 50,
                }}
                title={`${p.formula} · ${molarMass(p.formula).toFixed(2)} g/mol · clique duplo para descartar`}
              >
                {p.symbol}
              </div>
            ))}

            {/* Estado vazio */}
            {particles.length === 0 && (
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <p className="max-w-xs text-center text-xs leading-6 text-[var(--cc-text-muted)]">
                  {freeMode
                    ? "Crie elementos no catálogo e arraste um sobre o outro para combinar. Sem regras — experimente!"
                    : "Crie elementos no catálogo, arraste um sobre o outro para combiná-los e forme " +
                      goalFormula +
                      " nas condições certas para ganhar XP."}
                </p>
              </div>
            )}

            {particles.length > 0 && (
              <button
                type="button"
                onClick={clearBoard}
                className="absolute bottom-4 left-1/2 z-20 flex size-8 -translate-x-1/2 items-center justify-center rounded-full border border-[var(--cc-border)] bg-black/70 text-[var(--cc-text-muted)] backdrop-blur transition hover:border-[var(--cc-danger)] hover:text-[var(--cc-danger)]"
                title="Limpar a câmara"
              >
                <Trash2 className="size-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ── Modal de sucesso ───────────────────────────────────────────────── */}
      <Dialog open={successOpen} onOpenChange={setSuccessOpen}>
        <DialogContent className="cc-root max-w-sm rounded-2xl border-2 border-[var(--cc-accent)] bg-[var(--cc-bg)] text-center text-[#eee] sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl text-[var(--cc-accent)]">
              🎉 Síntese concluída!
            </DialogTitle>
            <DialogDescription className="text-center text-sm text-[#ccc]">
              Você criou{" "}
              <strong className="text-[var(--cc-accent)]">
                {compound.emoji} {compound.name}
              </strong>{" "}
              ({goalFormula}) com ligação {BOND_LABELS[compound.bond].toLowerCase()}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-lg font-bold text-[var(--cc-accent)]">+{lastGained} XP</p>
            {leveledTo && <p className="text-sm">Você alcançou o nível {leveledTo}!</p>}
            <div className="mx-auto h-40 w-40">
              {geometry && <MoleculeViewer geometry={geometry} />}
            </div>
            <div className="rounded-lg border border-[var(--cc-border)] bg-[var(--cc-element)] p-3 text-left text-xs leading-5 text-[#ccc]">
              {geometry?.lattice ? (
                <>
                  <span className="font-bold text-[var(--cc-accent)]">
                    {compound.bond === "ionic" ? "Retículo cristalino" : "Nuvem de elétrons"}:
                  </span>{" "}
                  {geometry.lattice}
                </>
              ) : (
                geometry && (
                  <>
                    <span className="font-bold text-[var(--cc-accent)]">GPE:</span> {geometry.gpe}{" "}
                    · <span className="font-bold text-[var(--cc-accent)]">GM:</span>{" "}
                    {geometry.gm} ·{" "}
                    <span className="font-bold text-[var(--cc-accent)]">Ângulo:</span>{" "}
                    {geometry.angle}
                  </>
                )
              )}
            </div>
            <Button
              className="w-full bg-[var(--cc-accent)] font-bold text-black hover:opacity-80"
              onClick={() => {
                setSuccessOpen(false);
                setCompoundIndex(
                  (i) =>
                    (i + 1 + Math.floor(Math.random() * (COMPOUNDS.length - 1))) %
                    COMPOUNDS.length,
                );
                setIsDaily(false);
                setParticles([]);
                awardLock.current = false;
                warnedFormula.current = null;
              }}
            >
              Próximo desafio
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Modal de personalização ────────────────────────────────────────── */}
      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent className="cc-root max-w-sm rounded-2xl border-2 border-[var(--cc-accent)] bg-[var(--cc-bg)] text-[#eee] sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-xl text-[var(--cc-accent)]">Personalizar</DialogTitle>
            <DialogDescription className="text-xs text-[#aaa]">
              Deixe o laboratório com a sua cara — as preferências ficam salvas na sua conta.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-5">
            <div>
              <Label className="text-xs">Cor de destaque</Label>
              <div className="mt-2 flex flex-wrap gap-2">
                {ACCENT_SWATCHES.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => applyAccent(color)}
                    className={`size-8 rounded-full border-2 transition hover:scale-110 ${
                      accent === color ? "border-white" : "border-transparent"
                    }`}
                    style={{ background: color }}
                    title={color}
                  />
                ))}
              </div>
            </div>
            <Separator className="bg-[var(--cc-border)]" />
            <div>
              <Label className="text-xs">Formato do átomo</Label>
              <div className="mt-2 flex gap-2">
                {SHAPE_SWATCHES.map((s) => (
                  <button
                    key={s.value}
                    type="button"
                    onClick={() => applyShape(s.value)}
                    className={`flex h-9 flex-1 items-center justify-center rounded border text-xs transition ${
                      shape === s.value
                        ? "border-[var(--cc-accent)] text-[var(--cc-accent)]"
                        : "border-[var(--cc-border)] text-[#aaa]"
                    }`}
                  >
                    <span
                      className="mr-1.5 inline-block size-3.5 bg-current"
                      style={{ borderRadius: s.value }}
                    />
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── Catálogo da barra lateral ───────────────────────────────────────────────

// ── Painel 3D arrastável da molécula ─────────────────────────────────────────
// Posição inicial no topo direito (abaixo da lâmpada), mas arrastável pelo
// cabeçalho para qualquer ponto da tela — assim nunca cobre as dicas.

function MoleculePanel({
  geometry,
  bondLabel,
}: {
  geometry: ReturnType<typeof molecularGeometry>;
  bondLabel: BondType;
}) {
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null);
  const [dragging, setDragging] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const offset = useRef({ dx: 0, dy: 0 });

  const onPointerDown = (e: React.PointerEvent) => {
    const panel = panelRef.current;
    if (!panel) return;
    const rect = panel.getBoundingClientRect();
    offset.current = { dx: e.clientX - rect.left, dy: e.clientY - rect.top };
    if (pos === null) {
      // Primeira arrastada: congela a posição atual do painel.
      const parent = panel.offsetParent as HTMLElement | null;
      const pRect = parent?.getBoundingClientRect();
      if (pRect) {
        setPos({ x: rect.left - pRect.left, y: rect.top - pRect.top });
      }
    }
    setDragging(true);
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragging) return;
    const parent = panelRef.current?.offsetParent as HTMLElement | null;
    const pRect = parent?.getBoundingClientRect();
    if (!pRect) return;
    setPos({
      x: e.clientX - pRect.left - offset.current.dx,
      y: e.clientY - pRect.top - offset.current.dy,
    });
  };

  const onPointerUp = () => setDragging(false);

  return (
    <div
      ref={panelRef}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      className="absolute z-20 hidden w-56 touch-none select-none rounded-xl border border-[var(--cc-border)] bg-black/85 shadow-lg backdrop-blur md:block"
      style={
        pos
          ? { left: pos.x, top: pos.y, right: "auto", cursor: dragging ? "grabbing" : "grab" }
          : { right: 16, top: 84, cursor: "grab" }
      }
    >
      <div className="flex cursor-grab items-center justify-between gap-1 border-b border-[var(--cc-border)] px-2 py-1.5 active:cursor-grabbing">
        <span className="text-[9px] uppercase tracking-wider text-[var(--cc-text-muted)]">
          Estrutura molecular
        </span>
        <span className="text-[9px] text-[var(--cc-text-muted)] opacity-60">⠿ arraste</span>
      </div>
      <div className="h-44">
        <MoleculeViewer geometry={geometry} />
      </div>
      <div className="px-2 pb-1.5 text-center text-[9px] leading-4 text-[var(--cc-text-muted)]">
        {geometry.lattice
          ? bondLabel === "ionic"
            ? "Retículo cristalino iônico"
            : "Mar de elétrons metálico"
          : `${geometry.gpe} → ${geometry.gm}`}
      </div>
    </div>
  );
}

function CatalogList({
  onPick,
  highlight,
}: {
  onPick: (symbol: string) => void;
  highlight: string[];
}) {
  const [query, setQuery] = useState("");

  const groups = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = PLAYABLE_CATALOG.filter(
      (el) => !q || el.symbol.toLowerCase().includes(q) || el.name.toLowerCase().includes(q),
    );
    const byCategory = new Map<string, typeof PLAYABLE_CATALOG>();
    for (const el of filtered) {
      const list = byCategory.get(el.category) ?? [];
      list.push(el);
      byCategory.set(el.category, list);
    }
    return [...byCategory.entries()];
  }, [query]);

  return (
    <div className="flex flex-col gap-4">
      <div className="relative">
        <Search className="pointer-events-none absolute left-2.5 top-2 size-3.5 text-[var(--cc-text-muted)]" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Procurar elemento…"
          className="cc-field h-8 pl-8 text-xs placeholder:text-[var(--cc-text-muted)]"
        />
      </div>

      {/* Tabela periódica completa, rolável horizontalmente */}
      <div className="rounded-lg border border-[var(--cc-border)] bg-[var(--cc-panel-raised)] p-2">
        <PeriodicTable onPick={onPick} highlight={highlight} />
      </div>

      {groups.map(([category, elements]) => (
        <div key={category}>
          <div className="mb-1.5 text-[9px] font-bold uppercase tracking-widest text-[var(--cc-text-muted)]">
            {category}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {elements.map((el) => (
              <button
                key={el.symbol}
                type="button"
                onClick={() => onPick(el.symbol)}
                className="cc-element px-2 py-1 text-[11px] font-bold"
                title={`${el.name} — clique para criar`}
              >
                {el.symbol}
              </button>
            ))}
          </div>
        </div>
      ))}

      {groups.length === 0 && (
        <p className="text-xs text-[var(--cc-text-muted)]">
          Nenhum elemento corresponde a “{query}”.
        </p>
      )}
    </div>
  );
}
