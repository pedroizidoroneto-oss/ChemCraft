import { useRef } from "react";
import { Link } from "react-router";
import { motion } from "framer-motion";
import { ArrowRight, Atom, FlaskConical, Sparkles, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { COMPOUNDS } from "@/lib/chemistry";
import heroArt from "@/assets/chemcraft-hero.svg";

const ACCENTS = ["#00ff66", "#00d0ff", "#ffd700", "#ff0055", "#9d00ff"];

const FEATURES = [
  {
    icon: FlaskConical,
    title: "Misture elementos de verdade",
    body: "Arraste átomos de uma tabela periódica completa para dentro da sua câmara de síntese e combine-os em compostos conhecidos — água, amônia, ácido sulfúrico e dezenas mais.",
  },
  {
    icon: Atom,
    title: "Aprenda a química por trás",
    body: "Declare o tipo de ligação antes de misturar e leia a geometria dos pares eletrônicos (GPE) e a forma molecular (GM) de tudo o que você cria. Compostos iônicos e metálicos ganham explicações próprias de retículo cristalino e nuvem de elétrons.",
  },
  {
    icon: Trophy,
    title: "Evolua ao sintetizar",
    body: "Cada reação bem-sucedida rende XP para o seu próximo nível de químico, e todo dia traz um novo composto desafiador para descobrir. Prefere explorar? O modo livre libera o laboratório sem regras.",
  },
  {
    icon: Sparkles,
    title: "Um laboratório com a sua cara",
    body: "Troque a cor de destaque, mude o formato dos átomos, ajuste temperatura, pressão, catalisadores, eletricidade e radiação — a interface inteira se transforma junto com as suas escolhas.",
  },
];

const SAMPLES = COMPOUNDS.slice(0, 8);

export default function Landing() {
  // A pré-visualização de tema troca a variável CSS neste contêiner; como o
  // estilo inline fica no mesmo elemento que .cc-root, ele vence a cascata.
  const rootRef = useRef<HTMLDivElement>(null);

  return (
    <div ref={rootRef} className="cc-root relative min-h-screen overflow-x-clip">
      {/* Fundo animado */}
      <div className="cc-grid-bg pointer-events-none absolute inset-0" />

      {/* Navegação */}
      <header className="relative z-10 mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2">
          <div className="flex size-9 items-center justify-center rounded-lg border border-[var(--cc-accent)] bg-[var(--cc-accent-10)]">
            <FlaskConical className="size-5 text-[var(--cc-accent)]" />
          </div>
          <span className="text-lg font-bold tracking-tight text-[#eee]">
            Chem<span className="text-[var(--cc-accent)]">Craft</span>
          </span>
        </div>
        <nav className="flex items-center gap-2">
          <Button
            asChild
            variant="ghost"
            className="text-[#ccc] hover:bg-[var(--cc-accent-10)] hover:text-[var(--cc-accent)]"
          >
            <Link to="/auth">Entrar</Link>
          </Button>
          <Button
            asChild
            className="bg-[var(--cc-accent)] font-semibold text-black hover:opacity-85"
          >
            <Link to="/auth">Abrir o laboratório</Link>
          </Button>
        </nav>
      </header>

      {/* Herói */}
      <section className="relative z-10 mx-auto grid w-full max-w-6xl items-center gap-10 px-6 pb-20 pt-12 sm:pt-16 lg:grid-cols-[1.1fr_0.9fr]">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center text-center lg:items-start lg:text-left"
        >
          <span className="rounded-full border border-[var(--cc-border)] bg-[var(--cc-accent-02)] px-4 py-1.5 text-xs font-medium uppercase tracking-widest text-[var(--cc-accent)]">
            O jogo de criação química
          </span>
          <h1 className="mt-6 max-w-3xl text-4xl font-bold leading-tight tracking-tight text-[#f5f5f5] sm:text-5xl xl:text-6xl">
            Construa matéria a partir de{" "}
            <span className="text-[var(--cc-accent)]">toda a tabela periódica</span>, uma
            ligação de cada vez
          </h1>
          <p className="mt-6 max-w-2xl text-base leading-7 text-[#aaa] sm:text-lg">
            O ChemCraft transforma química em um jogo de criação. Crie elementos, ajuste as
            condições da sua câmara de reação e sintetize compostos reais — enquanto o
            laboratório explica a geometria e a ciência das ligações por trás de cada
            molécula que você forma.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button
              asChild
              size="lg"
              className="bg-[var(--cc-accent)] px-8 text-base font-bold text-black hover:scale-[1.03] hover:opacity-90"
            >
              <Link to="/auth">
                Começar a sintetizar <ArrowRight className="ml-2 size-4" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="cc-element border-[var(--cc-border)] bg-transparent px-8 text-base text-[#eee] hover:text-[var(--cc-accent)]"
            >
              <Link to="/auth">Entrar na minha conta</Link>
            </Button>
          </div>
          <p className="mt-4 text-xs text-[var(--cc-text-muted)]">
            Grátis para jogar · sem cartão de crédito · seu progresso fica salvo na sua conta
          </p>
        </motion.div>

        {/* Arte da marca: átomos em estilo de impressão risográfica */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="relative mx-auto w-full max-w-md lg:max-w-none"
        >
          <div
            className="absolute inset-6 rounded-[2rem] opacity-40 blur-3xl"
            style={{ background: "radial-gradient(closest-side, #7b5cff, transparent)" }}
          />
          <motion.img
            src={heroArt}
            alt="Arte do ChemCraft: dois átomos e bolhas verdes sobre fundo roxo, em estilo de impressão risográfica"
            className="relative w-full rounded-[1.75rem] border border-white/10 shadow-[0_25px_80px_-20px_rgba(63,43,200,0.8)]"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          />
        </motion.div>

        {/* Chips flutuantes de compostos (largura total, abaixo das colunas) */}
        <div className="col-span-full mt-12 flex flex-wrap items-center justify-center gap-3">
          {SAMPLES.map((c, i) => (
            <motion.div
              key={c.formula}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 + i * 0.08, duration: 0.4 }}
              className={`cc-element flex items-center gap-2 rounded-full px-4 py-2 text-sm ${
                i % 2 === 0 ? "cc-float" : ""
              }`}
              style={{ animationDelay: `${i * 0.7}s` }}
            >
              <span className="text-base">{c.emoji}</span>
              <span className="font-bold text-[var(--cc-accent)]">{c.formula}</span>
              <span className="text-xs text-[#999]">{c.name}</span>
            </motion.div>
          ))}
        </div>

        {/* Playground de cores (largura total) */}
        <div className="col-span-full mt-10 flex items-center justify-center gap-3 text-xs text-[var(--cc-text-muted)]">
          <span>Experimente um tema:</span>
          {ACCENTS.map((color) => (
            <button
              key={color}
              type="button"
              onClick={() => rootRef.current?.style.setProperty("--cc-accent", color)}
              className="size-5 rounded-full border border-white/20 transition hover:scale-125"
              style={{ background: color }}
              title={`Tema ${color}`}
            />
          ))}
        </div>
      </section>

      {/* Recursos */}
      <section className="relative z-10 mx-auto w-full max-w-6xl px-6 pb-24">
        <div className="grid gap-5 sm:grid-cols-2">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.45, delay: i * 0.06 }}
              className="rounded-2xl border border-[var(--cc-border)] bg-[var(--cc-panel)] p-6 transition-colors hover:border-[var(--cc-accent)]"
            >
              <div className="flex size-10 items-center justify-center rounded-lg border border-[var(--cc-accent)] bg-[var(--cc-accent-10)]">
                <f.icon className="size-5 text-[var(--cc-accent)]" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-[#eee]">{f.title}</h3>
              <p className="mt-2 text-sm leading-6 text-[#aaa]">{f.body}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Como funciona */}
      <section className="relative z-10 mx-auto w-full max-w-6xl px-6 pb-24">
        <div className="rounded-2xl border border-[var(--cc-border)] bg-[var(--cc-panel-raised)] p-8 sm:p-12">
          <h2 className="text-2xl font-bold text-[#eee] sm:text-3xl">
            Três passos até a sua primeira síntese
          </h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-3">
            {[
              {
                step: "01",
                title: "Declare a ligação",
                body: "Covalente, iônica ou metálica? Escolha como os átomos do composto se conectam — o laboratório ensina o porquê antes de deixar você misturar.",
              },
              {
                step: "02",
                title: "Monte a fórmula",
                body: "Crie elementos e arraste uns sobre os outros. Veja a pressão comprimir a câmara, o calor brilhar em vermelho e as moléculas tremer sob eletricidade. Condições erradas? Os elementos simplesmente não se juntam.",
              },
              {
                step: "03",
                title: "Leia a ciência",
                body: "Ao sintetizar o alvo, o painel de feedback revela a geometria dos pares eletrônicos, a forma molecular, os ângulos de ligação e um desenho 3D da molécula.",
              },
            ].map((s) => (
              <div key={s.step} className="flex flex-col gap-2">
                <span className="text-3xl font-bold text-[var(--cc-accent-20)]">
                  {s.step}
                </span>
                <h4 className="font-semibold text-[#eee]">{s.title}</h4>
                <p className="text-sm leading-6 text-[#aaa]">{s.body}</p>
              </div>
            ))}
          </div>
          <Button
            asChild
            className="mt-10 bg-[var(--cc-accent)] px-6 font-bold text-black hover:opacity-90"
          >
            <Link to="/auth">
              Jogar o desafio diário <ArrowRight className="ml-2 size-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Rodapé */}
      <footer className="relative z-10 border-t border-[var(--cc-border)] px-6 py-8">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-4 text-xs text-[var(--cc-text-muted)] sm:flex-row">
          <div className="flex items-center gap-2">
            <FlaskConical className="size-4 text-[var(--cc-accent)]" />
            <span>
              Chem<span className="text-[var(--cc-accent)]">Craft</span> — crie química,
              aprenda química.
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/auth" className="hover:text-[var(--cc-accent)]">
              Entrar
            </Link>
            <Link to="/auth" className="hover:text-[var(--cc-accent)]">
              Criar conta
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
