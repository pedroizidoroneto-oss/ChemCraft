import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";

import { useAuth } from "@/hooks/use-auth";
import { ArrowRight, FlaskConical, Loader2, Mail, UserX } from "lucide-react";
import { Suspense, useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router";

interface AuthProps {
  redirectAfterAuth?: string;
}

function resolveRedirectAfterAuth(returnTo: string | null, fallback = "/dashboard") {
  if (returnTo?.startsWith("/") && !returnTo.startsWith("//")) {
    return returnTo;
  }
  return fallback;
}

function Auth({ redirectAfterAuth }: AuthProps = {}) {
  const { isLoading: authLoading, isAuthenticated, signIn } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirect = resolveRedirectAfterAuth(
    searchParams.get("returnTo"),
    redirectAfterAuth,
  );
  const [step, setStep] = useState<"signIn" | { email: string }>("signIn");
  const [otp, setOtp] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && isAuthenticated) {
      navigate(redirect);
    }
  }, [authLoading, isAuthenticated, navigate, redirect]);

  const handleEmailSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      const formData = new FormData(event.currentTarget);
      await signIn("email-otp", formData);
      setStep({ email: formData.get("email") as string });
    } catch (error) {
      console.error("Email sign-in error:", error);
      setError(
        error instanceof Error
          ? error.message
          : "Não foi possível enviar o código de verificação. Tente novamente.",
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleOtpSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      const formData = new FormData(event.currentTarget);
      await signIn("email-otp", formData);
      navigate(redirect);
    } catch (error) {
      console.error("OTP verification error:", error);
      setError("Esse código de verificação não está correto. Confira e tente de novo.");
      setOtp("");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuestLogin = async () => {
    setIsLoading(true);
    setError(null);
    try {
      await signIn("anonymous");
      navigate(redirect);
    } catch (error) {
      console.error("Guest login error:", error);
      setError(
        `Não foi possível iniciar uma sessão de convidado: ${
          error instanceof Error ? error.message : "erro desconhecido"
        }`,
      );
      setIsLoading(false);
    }
  };

  return (
    <div className="cc-root relative flex min-h-screen flex-col overflow-hidden">
      <div className="cc-grid-bg pointer-events-none absolute inset-0" />

      {/* Header */}
      <header className="relative z-10 px-6 py-6">
        <Link to="/" className="inline-flex items-center gap-2">
          <div className="flex size-9 items-center justify-center rounded-lg border border-[var(--cc-accent)] bg-[var(--cc-accent-10)]">
            <FlaskConical className="size-5 text-[var(--cc-accent)]" />
          </div>
          <span className="text-lg font-bold tracking-tight text-[#eee]">
            Chem<span className="text-[var(--cc-accent)]">Craft</span>
          </span>
        </Link>
      </header>

      {/* Auth card */}
      <div className="relative z-10 flex flex-1 items-center justify-center px-4 pb-16">
        <Card className="w-full max-w-sm rounded-2xl border-[var(--cc-border)] bg-[var(--cc-panel)] text-[#eee] shadow-[0_0_40px_var(--cc-accent-02)]">
          {step === "signIn" ? (
            <>
              <CardHeader className="text-center">
                <div className="mx-auto mb-2 flex size-12 items-center justify-center rounded-full border border-[var(--cc-accent)] bg-[var(--cc-accent-10)]">
                  <FlaskConical className="size-6 text-[var(--cc-accent)]" />
                </div>
                <CardTitle className="text-xl">Entrar no laboratório</CardTitle>
                <CardDescription className="text-[#aaa]">
                  Entre com seu e-mail para criar sua conta ou acessar — seus níveis,
                  descobertas e temas ficam salvos.
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleEmailSubmit}>
                <CardContent>
                  <div className="relative flex items-center gap-2">
                    <div className="relative flex-1">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-[var(--cc-text-muted)]" />
                      <Input
                        name="email"
                        placeholder="nome@exemplo.com"
                        type="email"
                        className="border-[var(--cc-border)] bg-[var(--cc-bg)] pl-9 text-[#eee] placeholder:text-[#666]"
                        disabled={isLoading}
                        required
                      />
                    </div>
                    <Button
                      type="submit"
                      variant="outline"
                      size="icon"
                      className="border-[var(--cc-border)] text-[#eee] hover:border-[var(--cc-accent)] hover:text-[var(--cc-accent)]"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <ArrowRight className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  {error && <p className="mt-2 text-sm text-[var(--cc-danger)]">{error}</p>}

                  <div className="mt-4">
                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t border-[var(--cc-border)]" />
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-[var(--cc-panel)] px-2 text-[var(--cc-text-muted)]">
                        Ou
                      </span>
                      </div>
                    </div>

                    <Button
                      type="button"
                      variant="outline"
                      className="mt-4 w-full border-[var(--cc-border)] text-[#eee] hover:border-[var(--cc-accent)] hover:text-[var(--cc-accent)]"
                      onClick={handleGuestLogin}
                      disabled={isLoading}
                    >
                      <UserX className="mr-2 h-4 w-4" />
                      Continuar como convidado
                    </Button>
                  </div>
                </CardContent>
              </form>
            </>
          ) : (
            <>
              <CardHeader className="mt-4 text-center">
                <CardTitle>Confira seu e-mail</CardTitle>
                <CardDescription className="text-[#aaa]">
                  Enviamos um código de 6 dígitos para {step.email}. Digite-o abaixo para
                  desbloquear o laboratório.
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleOtpSubmit}>
                <CardContent className="pb-4">
                  <input type="hidden" name="email" value={step.email} />
                  <input type="hidden" name="code" value={otp} />

                  <div className="flex justify-center">
                    <InputOTP
                      value={otp}
                      onChange={setOtp}
                      maxLength={6}
                      disabled={isLoading}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && otp.length === 6 && !isLoading) {
                          const form = (e.target as HTMLElement).closest("form");
                          if (form) form.requestSubmit();
                        }
                      }}
                    >
                      <InputOTPGroup>
                        {Array.from({ length: 6 }).map((_, index) => (
                          <InputOTPSlot key={index} index={index} />
                        ))}
                      </InputOTPGroup>
                    </InputOTP>
                  </div>
                  {error && (
                    <p className="mt-2 text-center text-sm text-[var(--cc-danger)]">
                      {error}
                    </p>
                  )}
                  <p className="mt-4 text-center text-sm text-[var(--cc-text-muted)]">
                    Não recebeu o código?{" "}
                    <Button
                      variant="link"
                      className="h-auto p-0 text-[var(--cc-accent)]"
                      onClick={() => setStep("signIn")}
                    >
                      Tentar de novo
                    </Button>
                  </p>
                </CardContent>
                <CardFooter className="flex-col gap-2">
                  <Button
                    type="submit"
                    className="w-full bg-[var(--cc-accent)] font-bold text-black hover:opacity-85"
                    disabled={isLoading || otp.length !== 6}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verificando…
                      </>
                    ) : (
                      <>
                        Verificar código
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setStep("signIn")}
                    disabled={isLoading}
                    className="w-full text-[#aaa] hover:text-[#eee]"
                  >
                    Usar outro e-mail
                  </Button>
                </CardFooter>
              </form>
            </>
          )}

          <div className="rounded-b-lg border-t border-[var(--cc-border)] bg-[var(--cc-panel-raised)] px-6 py-4 text-center text-xs text-[var(--cc-text-muted)]">
            Ao continuar, você concorda em manipular seus produtos químicos virtuais com responsabilidade.
          </div>
        </Card>
      </div>
    </div>
  );
}

export default function AuthPage(props: AuthProps) {
  return (
    <Suspense>
      <Auth {...props} />
    </Suspense>
  );
}
