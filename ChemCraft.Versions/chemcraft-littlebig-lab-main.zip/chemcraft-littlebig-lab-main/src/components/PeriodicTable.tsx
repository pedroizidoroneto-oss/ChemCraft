import { useMemo, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Maximize2, X } from "lucide-react";
import {
  CATALOG,
  CATALOG_BY_SYMBOL,
  ELEMENT_CATEGORIES,
  type ElementCategory,
  type ElementData,
} from "@/lib/chemistry";

// ── Tabela periódica completa (118 elementos) ───────────────────────────────
// Layout autêntico: 18 colunas × 7 períodos + 2 fileiras de f-block
// (lantanídeos e actinídeos) abaixo da tabela principal.

const COLUMNS = 18;
const PERIODS = 7;

const CATEGORY_COLORS: Record<ElementCategory, string> = {
  hydrogen: "bg-sky-500/15 border-sky-400/40 text-sky-200",
  alkali: "bg-rose-500/15 border-rose-500/40 text-rose-200",
  "alkaline-earth": "bg-orange-500/15 border-orange-500/40 text-orange-200",
  transition: "bg-amber-500/15 border-amber-500/40 text-amber-200",
  "post-transition": "bg-lime-500/15 border-lime-500/40 text-lime-200",
  metalloid: "bg-teal-500/15 border-teal-400/40 text-teal-200",
  nonmetal: "bg-emerald-500/15 border-emerald-500/40 text-emerald-200",
  halogen: "bg-cyan-500/15 border-cyan-500/40 text-cyan-200",
  noble: "bg-violet-500/15 border-violet-500/40 text-violet-200",
  lanthanide: "bg-fuchsia-500/15 border-fuchsia-500/40 text-fuchsia-200",
  actinide: "bg-pink-600/15 border-pink-500/40 text-pink-200",
};

const LEGEND: Array<{ label: string; classes: string }> = (
  [
    ["hydrogen", "Hidrogênio"],
    ["alkali", "Alcalinos"],
    ["alkaline-earth", "Alcalino-terrosos"],
    ["transition", "Transição"],
    ["post-transition", "Pós-transição"],
    ["metalloid", "Semimetais"],
    ["nonmetal", "Não metais"],
    ["halogen", "Halogênios"],
    ["noble", "Gases nobres"],
    ["lanthanide", "Lantanídeos"],
    ["actinide", "Actinídeos"],
  ] as Array<[ElementCategory, string]>
).map(([key, label]) => ({ label, classes: CATEGORY_COLORS[key] }));

const GROUP_LABELS = Array.from({ length: COLUMNS }, (_, i) => `${i + 1}`);

function ElementCell({
  el,
  size,
  dimmed,
  onActivate,
  onHover,
}: {
  el: ElementData;
  size: "mini" | "full";
  dimmed: boolean;
  onActivate: () => void;
  onHover?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onActivate}
      onMouseEnter={onHover}
      onFocus={onHover}
      title={`${el.name} (${el.category === "hydrogen" ? "Hidrogênio" : ELEMENT_CATEGORIES[el.category]})`}
      className={[
        "relative flex w-full flex-col items-center justify-center rounded border text-center leading-none transition-all",
        "hover:z-10 hover:scale-125 hover:shadow-[0_0_14px_var(--cc-accent-20)] focus-visible:z-10 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[var(--cc-accent)]",
        "aspect-square",
        size === "mini" ? "text-[9px]" : "text-base",
        CATEGORY_COLORS[el.category],
        dimmed ? "opacity-35" : "opacity-100",
      ].join(" ")}
    >
      <span className="absolute left-0.5 top-0.5 text-[6px] opacity-60">{el.atomicNumber}</span>
      <span className={`font-bold ${size === "mini" ? "text-[9px]" : "text-base"}`}>
        {el.symbol}
      </span>
      {size === "full" && (
        <span className="w-full truncate px-0.5 text-[6px] opacity-75">{el.name}</span>
      )}
    </button>
  );
}

function ElementDetail({ el }: { el: ElementData }) {
  const family =
    el.category === "hydrogen" ? ELEMENT_CATEGORIES.hydrogen : ELEMENT_CATEGORIES[el.category];
  return (
    <div className="rounded-lg border border-[var(--cc-border)] bg-[var(--cc-element)] p-4">
      <div className="flex items-baseline gap-3">
        <span className="text-3xl font-bold text-[var(--cc-accent)]">{el.symbol}</span>
        <span className="text-base font-semibold">{el.name}</span>
        <span className="text-xs text-[var(--cc-text-muted)]">
          #{el.atomicNumber} · {family}
          {el.group > 0 ? ` · Grupo ${el.group}` : ""} · Período {el.period}
        </span>
      </div>
      <dl className="mt-3 grid grid-cols-1 gap-x-6 gap-y-2 text-xs sm:grid-cols-3">
        <div>
          <dt className="text-[10px] uppercase tracking-wide text-[var(--cc-text-muted)] opacity-70">
            Massa atômica
          </dt>
          <dd className="font-medium">{el.atomicMass} u</dd>
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-wide text-[var(--cc-text-muted)] opacity-70">
            Família
          </dt>
          <dd className="font-medium">{family}</dd>
        </div>
        <div>
          <dt className="text-[10px] uppercase tracking-wide text-[var(--cc-text-muted)] opacity-70">
            Camada de valência
          </dt>
          <dd className="font-medium">{el.valence}</dd>
        </div>
      </dl>
      <p className="mt-3 text-[11px] leading-5 text-[var(--cc-text-muted)]">
        Use a camada de valência para deduzir a GPE, a GM e o tipo de ligação que este
        elemento prefere formar.
      </p>
    </div>
  );
}

export function PeriodicTable({
  highlight = [],
  onPick,
}: {
  /** Símbolos a destacar (ex.: os ingredientes do objetivo atual). */
  highlight?: string[];
  /** Se definido, clicar num elemento o insere na câmara. */
  onPick?: (symbol: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [hovered, setHovered] = useState<string | null>(null);
  const highlightSet = useMemo(() => new Set(highlight), [highlight]);

  const byPosition = useMemo(() => {
    const map = new Map<string, ElementData>();
    for (const el of CATALOG) {
      if (el.group === 0) continue; // f-block tratado abaixo
      map.set(`${el.period}:${el.group}`, el);
    }
    return map;
  }, []);

  const fRows = useMemo(
    () => [
      CATALOG.filter((el) => el.category === "lanthanide"),
      CATALOG.filter((el) => el.category === "actinide"),
    ],
    [],
  );

  const hoveredEl = hovered ? CATALOG_BY_SYMBOL[hovered] : null;

  const board = (size: "mini" | "full") => (
    <div className="flex flex-col gap-1">
      {/* Rótulos dos grupos */}
      <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${COLUMNS}, minmax(0, 1fr))` }}>
        {GROUP_LABELS.map((g) => (
          <div
            key={g}
            className="text-center text-[6px] font-semibold uppercase tracking-wider text-[var(--cc-text-muted)]"
          >
            {g}
          </div>
        ))}
      </div>

      {/* Períodos 1–7 */}
      {Array.from({ length: PERIODS }).map((_, row) => (
        <div
          key={row}
          className="grid gap-1"
          style={{ gridTemplateColumns: `repeat(${COLUMNS}, minmax(0, 1fr))` }}
        >
          {Array.from({ length: COLUMNS }).map((__, col) => {
            const el = byPosition.get(`${row + 1}:${col + 1}`);
            if (!el) return <div key={col} className="aspect-square" />;
            return (
              <ElementCell
                key={col}
                el={el}
                size={size}
                dimmed={highlightSet.size > 0 && !highlightSet.has(el.symbol)}
                onActivate={() => (onPick ? onPick(el.symbol) : setHovered(el.symbol))}
                onHover={size === "full" ? () => setHovered(el.symbol) : undefined}
              />
            );
          })}
        </div>
      ))}

      {/* Bloco f: lantanídeos e actinídeos */}
      {fRows.map((row, rowIndex) => (
        <div
          key={rowIndex}
          className="mt-1 grid gap-1"
          style={{ gridTemplateColumns: `repeat(${COLUMNS}, minmax(0, 1fr))` }}
        >
          <div className="col-span-2 flex items-center justify-end pr-1 text-[6px] uppercase tracking-wider text-[var(--cc-text-muted)]">
            {rowIndex === 0 ? "6ª" : "7ª"}
          </div>
          {row.map((el) => (
            <ElementCell
              key={el.symbol}
              el={el}
              size={size}
              dimmed={highlightSet.size > 0 && !highlightSet.has(el.symbol)}
              onActivate={() => (onPick ? onPick(el.symbol) : setHovered(el.symbol))}
              onHover={size === "full" ? () => setHovered(el.symbol) : undefined}
            />
          ))}
          {Array.from({ length: Math.max(0, COLUMNS - 2 - row.length) }).map((_, i) => (
            <div key={`pad-${i}`} className="aspect-square" />
          ))}
        </div>
      ))}
    </div>
  );

  return (
    <div className="flex flex-col gap-2">
      {/* Tabela completa inline (rolável) + gatilho de expansão */}
      <div className="cc-scroll relative overflow-x-auto pb-1">
        {board("mini")}
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="sticky right-0 top-1/2 z-20 float-right -translate-y-1/2 rounded-full border border-[var(--cc-accent)] bg-[var(--cc-bg)] p-1.5 text-[var(--cc-accent)] shadow transition hover:scale-110"
          title="Expandir tabela periódica"
        >
          <Maximize2 className="size-3" />
          <span className="sr-only">Expandir tabela periódica</span>
        </button>
      </div>

      <div className="flex flex-wrap gap-1 text-[8px] text-[var(--cc-text-muted)]">
        {LEGEND.map((l) => (
          <span key={l.label} className={`rounded border px-1 py-0.5 ${l.classes}`}>
            {l.label}
          </span>
        ))}
      </div>

      {/* Modal em tela cheia com dados detalhados */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent
          className="cc-root cc-scroll max-h-[92vh] max-w-4xl overflow-auto rounded-xl border-[var(--cc-border)] bg-[var(--cc-panel)] p-6 text-[#eee] sm:max-w-4xl"
          showCloseButton={false}
        >
          <div className="relative flex flex-col gap-4">
            <div>
              <DialogTitle className="text-lg font-bold text-[var(--cc-accent)]">
                Tabela Periódica
              </DialogTitle>
              <DialogDescription className="mt-1 text-xs text-[var(--cc-text-muted)]">
                Passe o mouse ou clique num elemento para ver número atômico, massa e
                distribuição eletrônica da camada de valência.
              </DialogDescription>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="absolute -top-1 right-0 rounded border border-[var(--cc-border)] p-1.5 text-[var(--cc-text-muted)] hover:text-[var(--cc-accent)]"
            >
              <X className="size-4" />
              <span className="sr-only">Fechar</span>
            </button>

            {board("full")}

            <div className="flex flex-wrap gap-1.5 text-[9px] text-[var(--cc-text-muted)]">
              {LEGEND.map((l) => (
                <span key={l.label} className={`rounded border px-1.5 py-0.5 ${l.classes}`}>
                  {l.label}
                </span>
              ))}
            </div>

            {hoveredEl ? (
              <ElementDetail el={hoveredEl} />
            ) : (
              <p className="text-xs text-[var(--cc-text-muted)]">
                Clique num elemento para inspecioná-lo.
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
