import { useEffect, useMemo, useState } from "react";
import type { MolecularGeometry } from "@/lib/chemistry";
import { CATALOG_BY_SYMBOL } from "@/lib/chemistry";

// ── Visualizador de geometria (desenho 3D estilizado em SVG) ────────────────
// Desenha a molécula-alvo com projeção pseudo-3D: os átomos ligados ficam em
// posições espaciais reais (tetraedro, pirâmide, angular etc.), com esferas
// sombreadas, ligações em perspectiva e rotação contínua da cena. Para retículo
// iônico e mar eletrônico metálico, desenha grades/nuvens dedicadas.

interface Vec3 {
  x: number;
  y: number;
  z: number;
}

interface AtomNode {
  pos: Vec3;
  symbol: string;
  /** Par isolado (desenhado como lóbulo translúcido). */
  lone?: boolean;
}

const CATEGORY_TINT: Record<string, string> = {
  nonmetal: "#4ade80",
  hydrogen: "#7dd3fc",
  halogen: "#22d3ee",
  noble: "#c084fc",
  metalloid: "#2dd4bf",
  alkali: "#fb7185",
  "alkaline-earth": "#fb923c",
  transition: "#fbbf24",
  "post-transition": "#a3e635",
  lanthanide: "#e879f9",
  actinide: "#f472b6",
};

function atomColor(symbol: string): string {
  const cat = CATALOG_BY_SYMBOL[symbol]?.category;
  return CATEGORY_TINT[cat ?? "nonmetal"] ?? "#4ade80";
}

// ── Projeção pseudo-3D ──────────────────────────────────────────────────────
function project(p: Vec3, yaw: number, pitch: number): { x: number; y: number; depth: number } {
  // Rotação em Y (yaw) depois em X (pitch), depois projeção perspectiva simples.
  const cosY = Math.cos(yaw);
  const sinY = Math.sin(yaw);
  const x1 = p.x * cosY - p.z * sinY;
  const z1 = p.x * sinY + p.z * cosY;
  const cosP = Math.cos(pitch);
  const sinP = Math.sin(pitch);
  const y1 = p.y * cosP - z1 * sinP;
  const z2 = p.y * sinP + z1 * cosP;
  const scale = 320 / (320 + z2 * 90);
  return { x: x1 * scale, y: y1 * scale, depth: z2 };
}

// ── Posições espaciais por forma (VSEPR) ────────────────────────────────────
const TETRA_ANGLES = [0, 120, 240].map((d) => (d * Math.PI) / 180);

function shapePositions(shapeKey: string): AtomNode[] {
  const r = 0.95;
  switch (shapeKey) {
    case "linear":
    case "linear-chain":
      return [
        { pos: { x: -r, y: 0, z: 0 }, symbol: "X" },
        { pos: { x: r, y: 0, z: 0 }, symbol: "X" },
      ];
    case "diatomic":
      return [
        { pos: { x: -0.6, y: 0, z: 0 }, symbol: "X" },
        { pos: { x: 0.6, y: 0, z: 0 }, symbol: "X" },
      ];
    case "trigonal-planar":
      return TETRA_ANGLES.map((a) => ({
        pos: { x: r * Math.cos(a), y: 0, z: r * Math.sin(a) },
        symbol: "X",
      }));
    case "tetrahedral":
      return [
        { pos: { x: 0, y: r, z: 0 }, symbol: "X" },
        ...TETRA_ANGLES.map((a) => ({
          pos: {
            x: 0.94 * r * Math.cos(a),
            y: -r / 3,
            z: 0.94 * r * Math.sin(a),
          },
          symbol: "X",
        })),
      ];
    case "trigonal-pyramidal":
      return [
        { pos: { x: 0, y: r, z: 0 }, symbol: "X" },
        ...TETRA_ANGLES.map((a) => ({
          pos: {
            x: 0.85 * r * Math.cos(a),
            y: -r / 2,
            z: 0.85 * r * Math.sin(a),
          },
          symbol: "X",
        })),
      ];
    case "bent":
      return [
        { pos: { x: 0, y: r, z: 0.15 }, symbol: "X" },
        { pos: { x: 0.85, y: -0.55, z: -0.15 }, symbol: "X" },
        { pos: { x: -0.85, y: -0.55, z: -0.15 }, symbol: "X", lone: true },
        { pos: { x: 0, y: 0.25, z: -0.95 }, symbol: "X", lone: true },
      ];
    case "trigonal-bipyramidal":
      return [
        { pos: { x: 0, y: r, z: 0 }, symbol: "X" },
        { pos: { x: 0, y: -r, z: 0 }, symbol: "X" },
        ...[0, 120, 240].map((d) => {
          const a = (d * Math.PI) / 180;
          return { pos: { x: r * Math.cos(a), y: 0, z: r * Math.sin(a) }, symbol: "X" };
        }),
      ];
    case "seesaw":
      return [
        { pos: { x: 0, y: r, z: 0 }, symbol: "X" },
        { pos: { x: 0, y: -r, z: 0 }, symbol: "X" },
        ...[90, 270].map((d) => {
          const a = (d * Math.PI) / 180;
          return { pos: { x: r * Math.cos(a), y: 0, z: r * Math.sin(a) }, symbol: "X" };
        }),
        { pos: { x: -0.8, y: 0, z: -0.6 }, symbol: "X", lone: true },
      ];
    case "octahedral":
      return [
        { pos: { x: 0, y: r, z: 0 }, symbol: "X" },
        { pos: { x: 0, y: -r, z: 0 }, symbol: "X" },
        { pos: { x: r, y: 0, z: 0 }, symbol: "X" },
        { pos: { x: -r, y: 0, z: 0 }, symbol: "X" },
        { pos: { x: 0, y: 0, z: r }, symbol: "X" },
        { pos: { x: 0, y: 0, z: -r }, symbol: "X" },
      ];
    case "square-pyramidal":
      return [
        { pos: { x: 0, y: r, z: 0 }, symbol: "X" },
        ...[
          [r, 0],
          [-r, 0],
          [0, r],
          [0, -r],
        ].map(([x, z]) => ({ pos: { x, y: -r / 3, z }, symbol: "X" })),
      ];
    case "square-planar":
      return [
        ...[
          [r, 0],
          [-r, 0],
          [0, r],
          [0, -r],
        ].map(([x, z]) => ({ pos: { x, y: 0, z }, symbol: "X" })),
        { pos: { x: 0, y: 0.9, z: 0 }, symbol: "X", lone: true },
        { pos: { x: 0, y: -0.9, z: 0 }, symbol: "X", lone: true },
      ];
    case "hexagon":
      return Array.from({ length: 6 }).map((_, i) => {
        const a = ((i * 60 + 30) * Math.PI) / 180;
        return {
          pos: { x: r * Math.cos(a), y: 0, z: r * Math.sin(a) },
          symbol: i % 2 === 0 ? "X" : "H",
        };
      });
    case "chain":
      // Cadeia tetraédrica simplificada (etanol/propano): zigzag de carbonos.
      return [
        { pos: { x: -0.9, y: 0.35, z: 0 }, symbol: "X" },
        { pos: { x: 0, y: -0.35, z: 0.3 }, symbol: "X" },
        { pos: { x: 0.9, y: 0.35, z: 0 }, symbol: "X" },
      ];
    default:
      return [{ pos: { x: 0, y: 0, z: 0 }, symbol: "X" }];
  }
}

// ── Componentes de desenho ──────────────────────────────────────────────────

function Sphere({
  cx,
  cy,
  r,
  color,
  label,
  dim,
}: {
  cx: number;
  cy: number;
  r: number;
  color: string;
  label: string;
  dim?: boolean;
}) {
  return (
    <g opacity={dim ? 0.45 : 1}>
      <circle cx={cx} cy={cy} r={r} fill="url(#ccSphereGrad)" style={{ color }} />
      <circle cx={cx} cy={cy} r={r} fill={color} fillOpacity={0.55} />
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeOpacity={0.9} strokeWidth={1.5} />
      <text
        x={cx}
        y={cy + r * 0.34}
        textAnchor="middle"
        fontSize={r * 0.9}
        fontWeight="bold"
        fill="#fff"
      >
        {label}
      </text>
    </g>
  );
}

function MoleculeScene({ geometry, symbols }: { geometry: MolecularGeometry; symbols: string[] }) {
  const [t, setT] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const loop = (now: number) => {
      setT((now - start) / 1000);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const yaw = t * 0.6;
  const pitch = -0.42 + Math.sin(t * 0.35) * 0.12;

  const symbolsKey = symbols.join(",");
  const nodes = useMemo(() => {
    const base = shapePositions(geometry.shapeKey);
    // Substitui os placeholders "X"/"H" pelos símbolos reais da fórmula.
    const realSymbols = symbols.length > 0 ? symbols : base.map((n) => n.symbol);
    let i = 0;
    return base.map((n) => ({
      ...n,
      symbol: n.lone ? "LP" : (realSymbols[i++ % realSymbols.length] ?? "X"),
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [geometry.shapeKey, symbolsKey]);

  const projected = nodes
    .map((n) => ({ ...n, p: project(n.pos, yaw, pitch) }))
    .sort((a, b) => a.p.depth - b.p.depth);

  const center = project({ x: 0, y: 0, z: 0 }, yaw, pitch);

  return (
    <svg viewBox="-150 -130 300 260" className="h-full w-full">
      <defs>
        <radialGradient id="ccSphereGrad" cx="35%" cy="30%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.85" />
          <stop offset="45%" stopColor="#ffffff" stopOpacity="0.12" />
          <stop offset="100%" stopColor="#000000" stopOpacity="0.35" />
        </radialGradient>
        <radialGradient id="ccFloorGrad" cx="50%" cy="50%">
          <stop offset="0%" stopColor="var(--cc-accent)" stopOpacity="0.25" />
          <stop offset="100%" stopColor="var(--cc-accent)" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* Sombra no "chão" */}
      <ellipse cx={0} cy={92} rx={95} ry={22} fill="url(#ccFloorGrad)" />

      {/* Ligações do centro para cada átomo (atrás) */}
      {projected
        .filter((n) => !n.lone)
        .filter((n) => n.p.depth <= 0)
        .map((n, i) => (
          <line
            key={`b-b-${i}`}
            x1={center.x}
            y1={center.y}
            x2={n.p.x * 0.92}
            y2={n.p.y * 0.92}
            stroke="var(--cc-accent)"
            strokeOpacity={0.55}
            strokeWidth={5}
            strokeLinecap="round"
          />
        ))}

      {/* Átomos de trás */}
      {projected
        .filter((n) => n.p.depth <= 0)
        .map((n, i) => (
          <Sphere
            key={`a-b-${i}`}
            cx={n.p.x * 0.92}
            cy={n.p.y * 0.92}
            r={n.lone ? 13 : 19}
            color={n.lone ? "#94a3b8" : atomColor(n.symbol)}
            label={n.symbol}
            dim={n.lone}
          />
        ))}

      {/* Átomo central */}
      <Sphere cx={center.x} cy={center.y} r={24} color={atomColor(geometry.central)} label={geometry.central === "—" ? "•" : geometry.central} />

      {/* Ligações da frente */}
      {projected
        .filter((n) => !n.lone)
        .filter((n) => n.p.depth > 0)
        .map((n, i) => (
          <line
            key={`b-f-${i}`}
            x1={center.x}
            y1={center.y}
            x2={n.p.x * 0.92}
            y2={n.p.y * 0.92}
            stroke="var(--cc-accent)"
            strokeOpacity={0.75}
            strokeWidth={5}
            strokeLinecap="round"
          />
        ))}

      {/* Átomos da frente + pares isolados */}
      {projected
        .filter((n) => n.p.depth > 0)
        .map((n, i) => (
          <Sphere
            key={`a-f-${i}`}
            cx={n.p.x * 0.92}
            cy={n.p.y * 0.92}
            r={n.lone ? 13 : 19}
            color={n.lone ? "#94a3b8" : atomColor(n.symbol)}
            label={n.symbol}
            dim={n.lone}
          />
        ))}
    </svg>
  );
}

/** Retículo cristalino iônico: grade 3×3×3 alternando cátions e ânions. */
function LatticeScene() {
  const [t, setT] = useState(0);
  useEffect(() => {
    let raf = 0;
    let start = performance.now();
    const loop = (now: number) => {
      if (now - start > 3600_000) start = now; // evita drift de precisão
      setT((now - start) / 1000);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const yaw = t * 0.45;
  const pitch = -0.5;
  const n = 3;
  const spacing = 34;
  const nodes: Array<{ p: ReturnType<typeof project>; positive: boolean }> = [];
  for (let x = 0; x < n; x++) {
    for (let y = 0; y < n; y++) {
      for (let z = 0; z < n; z++) {
        const pos: Vec3 = {
          x: (x - 1) * spacing,
          y: (y - 1) * spacing,
          z: (z - 1) * spacing,
        };
        nodes.push({ p: project(pos, yaw, pitch), positive: (x + y + z) % 2 === 0 });
      }
    }
  }
  nodes.sort((a, b) => a.p.depth - b.p.depth);

  return (
    <svg viewBox="-150 -130 300 260" className="h-full w-full">
      <defs>
        <radialGradient id="ccSphereGrad2" cx="35%" cy="30%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.85" />
          <stop offset="45%" stopColor="#ffffff" stopOpacity="0.12" />
          <stop offset="100%" stopColor="#000000" stopOpacity="0.35" />
        </radialGradient>
      </defs>
      <ellipse cx={0} cy={98} rx={95} ry={20} fill="var(--cc-accent)" fillOpacity={0.08} />
      {nodes.map((nd, i) => (
        <g key={i}>
          {i > 0 && (
            <line
              x1={nodes[i - 1].p.x}
              y1={nodes[i - 1].p.y}
              x2={nd.p.x}
              y2={nd.p.y}
              stroke="var(--cc-accent)"
              strokeOpacity={0.08}
              strokeWidth={2}
            />
          )}
          <circle
            cx={nd.p.x}
            cy={nd.p.y}
            r={11}
            fill={nd.positive ? "#f87171" : "#60a5fa"}
            fillOpacity={0.8}
            stroke={nd.positive ? "#fca5a5" : "#93c5fd"}
            strokeWidth={1}
          />
          <text
            x={nd.p.x}
            y={nd.p.y + 3.5}
            textAnchor="middle"
            fontSize={9}
            fontWeight="bold"
            fill="#0b0d0c"
          >
            {nd.positive ? "+" : "−"}
          </text>
        </g>
      ))}
    </svg>
  );
}

/** Mar eletrônico metálico: cátions em grade + nuvem de elétrons pulsante. */
function ElectronSeaScene() {
  const [t, setT] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const loop = (now: number) => {
      setT((now - start) / 1000);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const cations: Array<{ x: number; y: number }> = [];
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 5; col++) {
      cations.push({ x: -80 + col * 40, y: -40 + row * 40 });
    }
  }
  const electrons = Array.from({ length: 14 }).map((_, i) => {
    const a = t * 0.9 + (i * Math.PI * 2) / 14;
    const rx = 105 + Math.sin(t * 1.3 + i) * 14;
    const ry = 62 + Math.cos(t * 1.1 + i * 2) * 10;
    return { x: Math.cos(a) * rx, y: Math.sin(a) * ry, i };
  });

  return (
    <svg viewBox="-150 -130 300 260" className="h-full w-full">
      <ellipse cx={0} cy={0} rx={130} ry={85} fill="var(--cc-accent)" fillOpacity={0.1}>
        <animate attributeName="fill-opacity" values="0.06;0.16;0.06" dur="3s" repeatCount="indefinite" />
      </ellipse>
      <ellipse cx={0} cy={0} rx={130} ry={85} fill="none" stroke="var(--cc-accent)" strokeOpacity={0.3} strokeDasharray="6 5" />
      {cations.map((c, i) => (
        <g key={i}>
          <circle cx={c.x} cy={c.y} r={12} fill="#fbbf24" fillOpacity={0.85} stroke="#fde68a" strokeWidth={1} />
          <text x={c.x} y={c.y + 4} textAnchor="middle" fontSize={11} fontWeight="bold" fill="#0b0d0c">
            +
          </text>
        </g>
      ))}
      {electrons.map((e) => (
        <circle key={e.i} cx={e.x} cy={e.y} r={4} fill="#38bdf8">
          <animate attributeName="opacity" values="0.5;1;0.5" dur="1.6s" begin={`${(e.i % 5) * 0.2}s`} repeatCount="indefinite" />
        </circle>
      ))}
      <text x={0} y={112} textAnchor="middle" fontSize={11} fill="#9ca3af">
        e⁻ livres
      </text>
    </svg>
  );
}

export function MoleculeViewer({ geometry }: { geometry: MolecularGeometry }) {
  const symbols = useMemo(() => {
    // Símbolos reais dos átomos ligados, derivados da fórmula.
    const map: Record<string, number> = {};
    const regex = /([A-Z][a-z]*)(\d*)/g;
    let m: RegExpExecArray | null;
    while ((m = regex.exec(geometry.formula)) !== null) {
      map[m[1]] = (map[m[1]] ?? 0) + (parseInt(m[2], 10) || 1);
    }
    delete map[geometry.central];
    const out: string[] = [];
    for (const [sym, n] of Object.entries(map)) {
      for (let i = 0; i < n; i++) out.push(sym);
    }
    return out;
  }, [geometry.formula, geometry.central]);

  if (geometry.shapeKey === "lattice") return <LatticeScene />;
  if (geometry.shapeKey === "electron-sea") return <ElectronSeaScene />;
  return <MoleculeScene geometry={geometry} symbols={symbols} />;
}
