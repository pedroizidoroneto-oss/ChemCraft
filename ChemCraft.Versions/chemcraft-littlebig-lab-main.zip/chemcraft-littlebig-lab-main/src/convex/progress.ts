import { getAuthUserId } from "@convex-dev/auth/server";
import { v } from "convex/values";
import { nextXpRequired, xpForCompound } from "../lib/chemistry";
import { mutation, query } from "./_generated/server";

/**
 * ChemCraft player progression and appearance persistence.
 * One row per user, created lazily on first write.
 */

const APPEARANCE_DEFAULTS = {
  accentColor: "#00ff66",
  particleShape: "50%",
};

/** Get the signed-in player's progress, or defaults if they haven't played yet. */
export const getProgress = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return null;

    const existing = await ctx.db
      .query("progress")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existing !== null) return existing;

    return {
      _id: null,
      _creationTime: 0,
      userId,
      level: 1,
      xp: 0,
      xpRequired: 100,
      completedCompounds: [] as string[],
      appearance: APPEARANCE_DEFAULTS,
      session: undefined,
    };
  },
});

/** Persist appearance preferences (accent color and particle shape). */
export const setAppearance = mutation({
  args: {
    accentColor: v.string(),
    particleShape: v.string(),
  },
  handler: async (ctx, { accentColor, particleShape }) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("Not authenticated");

    const existing = await ctx.db
      .query("progress")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    const appearance = { accentColor, particleShape };

    if (existing) {
      await ctx.db.patch(existing._id, { appearance });
    } else {
      await ctx.db.insert("progress", {
        userId,
        level: 1,
        xp: 0,
        xpRequired: 100,
        completedCompounds: [],
        appearance,
        session: undefined,
      });
    }
  },
});

/**
 * Persist the current lab session (mode, mission, bond answer, environment and
 * particles on the board) so the player resumes exactly where they left off.
 */
export const saveSession = mutation({
  args: {
    mode: v.union(v.literal("mission"), v.literal("free")),
    compoundIndex: v.number(),
    isDaily: v.boolean(),
    bondAnswer: v.optional(v.string()),
    env: v.object({
      temperature: v.number(),
      pressure: v.number(),
      catalyst: v.string(),
      electricity: v.boolean(),
      radiation: v.boolean(),
    }),
    particles: v.array(
      v.object({
        symbol: v.string(),
        formula: v.string(),
        x: v.number(),
        y: v.number(),
      }),
    ),
  },
  handler: async (ctx, session) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) return; // silent: session save is best-effort

    const existing = await ctx.db
      .query("progress")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existing) {
      await ctx.db.patch(existing._id, { session });
    } else {
      await ctx.db.insert("progress", {
        userId,
        level: 1,
        xp: 0,
        xpRequired: 100,
        completedCompounds: [],
        appearance: APPEARANCE_DEFAULTS,
        session,
      });
    }
  },
});

/**
 * Award XP for a synthesis. Math runs server-side so the client can't cheat:
 * the mutation re-derives the XP from the formula and daily-challenge flag.
 */
export const awardXp = mutation({
  args: {
    formula: v.string(),
    isDailyChallenge: v.boolean(),
  },
  handler: async (ctx, { formula, isDailyChallenge }) => {
    const userId = await getAuthUserId(ctx);
    if (userId === null) throw new Error("Not authenticated");

    const gained = xpForCompound(formula, isDailyChallenge);

    const existing = await ctx.db
      .query("progress")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existing) {
      let level = existing.level;
      let xp = existing.xp + gained;
      let xpRequired = existing.xpRequired;
      let leveledUpTo: number | null = null;

      while (xp >= xpRequired) {
        xp -= xpRequired;
        level += 1;
        xpRequired = nextXpRequired(xpRequired);
        leveledUpTo = level;
      }

      await ctx.db.patch(existing._id, {
        level,
        xp,
        xpRequired,
        completedCompounds: existing.completedCompounds.includes(formula)
          ? existing.completedCompounds
          : [...existing.completedCompounds, formula],
      });

      return { gained, level, xp, xpRequired, leveledUpTo };
    }

    // First synthesis ever: start from defaults and credit the XP.
    let level = 1;
    let xp = gained;
    let xpRequired = 100;
    let leveledUpTo: number | null = null;

    while (xp >= xpRequired) {
      xp -= xpRequired;
      level += 1;
      xpRequired = nextXpRequired(xpRequired);
      leveledUpTo = level;
    }

    await ctx.db.insert("progress", {
      userId,
      level,
      xp,
      xpRequired,
      completedCompounds: [formula],
      appearance: APPEARANCE_DEFAULTS,
    });

    return { gained, level, xp, xpRequired, leveledUpTo };
  },
});
