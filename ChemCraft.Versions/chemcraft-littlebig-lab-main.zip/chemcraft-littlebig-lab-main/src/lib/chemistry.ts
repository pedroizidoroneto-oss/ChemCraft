// ── ChemCraft: dados e funções de química ───────────────────────────────────
// Dados puros + funções compartilhadas pela UI do laboratório.
// Sem imports de React ou Convex aqui.

export type ElementCategory =
  | "nonmetal"
  | "alkali"
  | "alkaline-earth"
  | "transition"
  | "post-transition"
  | "metalloid"
  | "halogen"
  | "noble"
  | "lanthanide"
  | "actinide"
  | "hydrogen";

export const ELEMENT_CATEGORIES: Record<ElementCategory, string> = {
  hydrogen: "Hidrogênio",
  nonmetal: "Não metais",
  alkali: "Metais alcalinos",
  "alkaline-earth": "Metais alcalino-terrosos",
  transition: "Metais de transição",
  "post-transition": "Pós-transição",
  metalloid: "Semimetais",
  halogen: "Halogênios",
  noble: "Gases nobres",
  lanthanide: "Lantanídeos",
  actinide: "Actinídeos",
};

export interface ElementData {
  symbol: string;
  name: string;
  atomicNumber: number;
  atomicMass: number;
  category: ElementCategory;
  /** Distribuição eletrônica da camada de valência. */
  valence: string;
  /** Posição na tabela periódica: grupo (1–18) e período (1–7). */
  group: number;
  period: number;
}

type RawElement = [
  symbol: string,
  name: string,
  atomicNumber: number,
  atomicMass: number,
  category: ElementCategory,
  valence: string,
  group: number,
  period: number,
];

// Tabela periódica completa: 118 elementos com grupo/período reais.
const RAW_ELEMENTS: RawElement[] = [
  ["H", "Hidrogênio", 1, 1.008, "hydrogen", "1s¹", 1, 1],
  ["He", "Hélio", 2, 4.0026, "noble", "1s²", 18, 1],
  ["Li", "Lítio", 3, 6.94, "alkali", "2s¹", 1, 2],
  ["Be", "Berílio", 4, 9.0122, "alkaline-earth", "2s²", 2, 2],
  ["B", "Boro", 5, 10.81, "metalloid", "2s² 2p¹", 13, 2],
  ["C", "Carbono", 6, 12.011, "nonmetal", "2s² 2p²", 14, 2],
  ["N", "Nitrogênio", 7, 14.007, "nonmetal", "2s² 2p³", 15, 2],
  ["O", "Oxigênio", 8, 15.999, "nonmetal", "2s² 2p⁴", 16, 2],
  ["F", "Flúor", 9, 18.998, "halogen", "2s² 2p⁵", 17, 2],
  ["Ne", "Neônio", 10, 20.18, "noble", "2s² 2p⁶", 18, 2],
  ["Na", "Sódio", 11, 22.99, "alkali", "3s¹", 1, 3],
  ["Mg", "Magnésio", 12, 24.305, "alkaline-earth", "3s²", 2, 3],
  ["Al", "Alumínio", 13, 26.982, "post-transition", "3s² 3p¹", 13, 3],
  ["Si", "Silício", 14, 28.085, "metalloid", "3s² 3p²", 14, 3],
  ["P", "Fósforo", 15, 30.974, "nonmetal", "3s² 3p³", 15, 3],
  ["S", "Enxofre", 16, 32.06, "nonmetal", "3s² 3p⁴", 16, 3],
  ["Cl", "Cloro", 17, 35.45, "halogen", "3s² 3p⁵", 17, 3],
  ["Ar", "Argônio", 18, 39.948, "noble", "3s² 3p⁶", 18, 3],
  ["K", "Potássio", 19, 39.098, "alkali", "4s¹", 1, 4],
  ["Ca", "Cálcio", 20, 40.078, "alkaline-earth", "4s²", 2, 4],
  ["Sc", "Escândio", 21, 44.956, "transition", "3d¹ 4s²", 3, 4],
  ["Ti", "Titânio", 22, 47.867, "transition", "3d² 4s²", 4, 4],
  ["V", "Vanádio", 23, 50.942, "transition", "3d³ 4s²", 5, 4],
  ["Cr", "Cromo", 24, 51.996, "transition", "3d⁵ 4s¹", 6, 4],
  ["Mn", "Manganês", 25, 54.938, "transition", "3d⁵ 4s²", 7, 4],
  ["Fe", "Ferro", 26, 55.845, "transition", "3d⁶ 4s²", 8, 4],
  ["Co", "Cobalto", 27, 58.933, "transition", "3d⁷ 4s²", 9, 4],
  ["Ni", "Níquel", 28, 58.693, "transition", "3d⁸ 4s²", 10, 4],
  ["Cu", "Cobre", 29, 63.546, "transition", "3d¹⁰ 4s¹", 11, 4],
  ["Zn", "Zinco", 30, 65.38, "transition", "3d¹⁰ 4s²", 12, 4],
  ["Ga", "Gálio", 31, 69.723, "post-transition", "4s² 4p¹", 13, 4],
  ["Ge", "Germânio", 32, 72.63, "metalloid", "4s² 4p²", 14, 4],
  ["As", "Arsênio", 33, 74.922, "metalloid", "4s² 4p³", 15, 4],
  ["Se", "Selênio", 34, 78.971, "nonmetal", "4s² 4p⁴", 16, 4],
  ["Br", "Bromo", 35, 79.904, "halogen", "4s² 4p⁵", 17, 4],
  ["Kr", "Criptônio", 36, 83.798, "noble", "4s² 4p⁶", 18, 4],
  ["Rb", "Rubídio", 37, 85.468, "alkali", "5s¹", 1, 5],
  ["Sr", "Estrôncio", 38, 87.62, "alkaline-earth", "5s²", 2, 5],
  ["Y", "Ítrio", 39, 88.906, "transition", "4d¹ 5s²", 3, 5],
  ["Zr", "Zircônio", 40, 91.224, "transition", "4d² 5s²", 4, 5],
  ["Nb", "Nióbio", 41, 92.906, "transition", "4d⁴ 5s¹", 5, 5],
  ["Mo", "Molibdênio", 42, 95.95, "transition", "4d⁵ 5s¹", 6, 5],
  ["Tc", "Tecnécio", 43, 98, "transition", "4d⁵ 5s²", 7, 5],
  ["Ru", "Rutênio", 44, 101.07, "transition", "4d⁷ 5s¹", 8, 5],
  ["Rh", "Ródio", 45, 102.91, "transition", "4d⁸ 5s¹", 9, 5],
  ["Pd", "Paládio", 46, 106.42, "transition", "4d¹⁰", 10, 5],
  ["Ag", "Prata", 47, 107.87, "transition", "4d¹⁰ 5s¹", 11, 5],
  ["Cd", "Cádmio", 48, 112.41, "transition", "4d¹⁰ 5s²", 12, 5],
  ["In", "Índio", 49, 114.82, "post-transition", "5s² 5p¹", 13, 5],
  ["Sn", "Estanho", 50, 118.71, "post-transition", "5s² 5p²", 14, 5],
  ["Sb", "Antimônio", 51, 121.76, "metalloid", "5s² 5p³", 15, 5],
  ["Te", "Telúrio", 52, 127.6, "metalloid", "5s² 5p⁴", 16, 5],
  ["I", "Iodo", 53, 126.9, "halogen", "5s² 5p⁵", 17, 5],
  ["Xe", "Xenônio", 54, 131.29, "noble", "5s² 5p⁶", 18, 5],
  ["Cs", "Césio", 55, 132.91, "alkali", "6s¹", 1, 6],
  ["Ba", "Bário", 56, 137.33, "alkaline-earth", "6s²", 2, 6],
  ["La", "Lantânio", 57, 138.91, "lanthanide", "5d¹ 6s²", 3, 6],
  ["Ce", "Cério", 58, 140.12, "lanthanide", "4f¹ 5d¹ 6s²", 0, 6],
  ["Pr", "Praseodímio", 59, 140.91, "lanthanide", "4f³ 6s²", 0, 6],
  ["Nd", "Neodímio", 60, 144.24, "lanthanide", "4f⁴ 6s²", 0, 6],
  ["Pm", "Promécio", 61, 145, "lanthanide", "4f⁵ 6s²", 0, 6],
  ["Sm", "Samário", 62, 150.36, "lanthanide", "4f⁶ 6s²", 0, 6],
  ["Eu", "Európio", 63, 151.96, "lanthanide", "4f⁷ 6s²", 0, 6],
  ["Gd", "Gadolínio", 64, 157.25, "lanthanide", "4f⁷ 5d¹ 6s²", 0, 6],
  ["Tb", "Térbio", 65, 158.93, "lanthanide", "4f⁹ 6s²", 0, 6],
  ["Dy", "Disprósio", 66, 162.5, "lanthanide", "4f¹⁰ 6s²", 0, 6],
  ["Ho", "Hólmio", 67, 164.93, "lanthanide", "4f¹¹ 6s²", 0, 6],
  ["Er", "Érbio", 68, 167.26, "lanthanide", "4f¹² 6s²", 0, 6],
  ["Tm", "Túlio", 69, 168.93, "lanthanide", "4f¹³ 6s²", 0, 6],
  ["Yb", "Itérbio", 70, 173.05, "lanthanide", "4f¹⁴ 6s²", 0, 6],
  ["Lu", "Lutécio", 71, 174.97, "lanthanide", "4f¹⁴ 5d¹ 6s²", 0, 6],
  ["Hf", "Háfnio", 72, 178.49, "transition", "5d² 6s²", 4, 6],
  ["Ta", "Tântalo", 73, 180.95, "transition", "5d³ 6s²", 5, 6],
  ["W", "Tungstênio", 74, 183.84, "transition", "5d⁴ 6s²", 6, 6],
  ["Re", "Rênio", 75, 186.21, "transition", "5d⁵ 6s²", 7, 6],
  ["Os", "Ósmio", 76, 190.23, "transition", "5d⁶ 6s²", 8, 6],
  ["Ir", "Irídio", 77, 192.22, "transition", "5d⁷ 6s²", 9, 6],
  ["Pt", "Platina", 78, 195.08, "transition", "5d⁹ 6s¹", 10, 6],
  ["Au", "Ouro", 79, 196.97, "transition", "5d¹⁰ 6s¹", 11, 6],
  ["Hg", "Mercúrio", 80, 200.59, "transition", "5d¹⁰ 6s²", 12, 6],
  ["Tl", "Tálio", 81, 204.38, "post-transition", "6s² 6p¹", 13, 6],
  ["Pb", "Chumbo", 82, 207.2, "post-transition", "6s² 6p²", 14, 6],
  ["Bi", "Bismuto", 83, 208.98, "post-transition", "6s² 6p³", 15, 6],
  ["Po", "Polônio", 84, 209, "post-transition", "6s² 6p⁴", 16, 6],
  ["At", "Astato", 85, 210, "halogen", "6s² 6p⁵", 17, 6],
  ["Rn", "Radônio", 86, 222, "noble", "6s² 6p⁶", 18, 6],
  ["Fr", "Frâncio", 87, 223, "alkali", "7s¹", 1, 7],
  ["Ra", "Rádio", 88, 226, "alkaline-earth", "7s²", 2, 7],
  ["Ac", "Actínio", 89, 227, "actinide", "6d¹ 7s²", 3, 7],
  ["Th", "Tório", 90, 232.04, "actinide", "6d² 7s²", 0, 7],
  ["Pa", "Protactínio", 91, 231.04, "actinide", "5f² 6d¹ 7s²", 0, 7],
  ["U", "Urânio", 92, 238.03, "actinide", "5f³ 6d¹ 7s²", 0, 7],
  ["Np", "Netúnio", 93, 237, "actinide", "5f⁴ 6d¹ 7s²", 0, 7],
  ["Pu", "Plutônio", 94, 244.06, "actinide", "5f⁶ 7s²", 0, 7],
  ["Am", "Amerício", 95, 243, "actinide", "5f⁷ 7s²", 0, 7],
  ["Cm", "Cúrio", 96, 247, "actinide", "5f⁷ 6d¹ 7s²", 0, 7],
  ["Bk", "Berquélio", 97, 247, "actinide", "5f⁹ 7s²", 0, 7],
  ["Cf", "Califórnio", 98, 251, "actinide", "5f¹⁰ 7s²", 0, 7],
  ["Es", "Einstênio", 99, 252, "actinide", "5f¹¹ 7s²", 0, 7],
  ["Fm", "Férmio", 100, 257, "actinide", "5f¹² 7s²", 0, 7],
  ["Md", "Mendelévio", 101, 258, "actinide", "5f¹³ 7s²", 0, 7],
  ["No", "Nobélio", 102, 259, "actinide", "5f¹⁴ 7s²", 0, 7],
  ["Lr", "Laurêncio", 103, 266, "actinide", "5f¹⁴ 7s² 7p¹", 0, 7],
  ["Rf", "Rutherfórdio", 104, 267, "transition", "6d² 7s²", 4, 7],
  ["Db", "Dúbnio", 105, 268, "transition", "6d³ 7s²", 5, 7],
  ["Sg", "Seabórgio", 106, 269, "transition", "6d⁴ 7s²", 6, 7],
  ["Bh", "Bóhrio", 107, 270, "transition", "6d⁵ 7s²", 7, 7],
  ["Hs", "Hássio", 108, 277, "transition", "6d⁶ 7s²", 8, 7],
  ["Mt", "Meitnério", 109, 278, "transition", "6d⁷ 7s²", 9, 7],
  ["Ds", "Darmstácio", 110, 281, "transition", "6d⁹ 7s¹", 10, 7],
  ["Rg", "Roentgênio", 111, 282, "transition", "6d¹⁰ 7s¹", 11, 7],
  ["Cn", "Copernício", 112, 285, "transition", "6d¹⁰ 7s²", 12, 7],
  ["Nh", "Nihônio", 113, 286, "post-transition", "7s² 7p¹", 13, 7],
  ["Fl", "Fleróvio", 114, 289, "post-transition", "7s² 7p²", 14, 7],
  ["Mc", "Moscóvio", 115, 290, "post-transition", "7s² 7p³", 15, 7],
  ["Lv", "Livermório", 116, 293, "post-transition", "7s² 7p⁴", 16, 7],
  ["Ts", "Tenessino", 117, 294, "halogen", "7s² 7p⁵", 17, 7],
  ["Og", "Oganessônio", 118, 294, "noble", "7s² 7p⁶", 18, 7],
];

export const CATALOG: ElementData[] = RAW_ELEMENTS.map(
  ([symbol, name, atomicNumber, atomicMass, category, valence, group, period]) => ({
    symbol,
    name,
    atomicNumber,
    atomicMass,
    category,
    valence,
    group,
    period,
  }),
);

export const CATALOG_BY_SYMBOL: Record<string, ElementData> = Object.fromEntries(
  CATALOG.map((el) => [el.symbol, el]),
);

/** Todos os elementos que podem ser criados no laboratório (para a sidebar). */
export function elementName(symbol: string): string {
  return CATALOG_BY_SYMBOL[symbol]?.name ?? symbol;
}

/** Elementos jogáveis no laboratório (evita os superpesados teóricos). */
const PLAYABLE_MAX_Z = 94;
export const PLAYABLE_CATALOG: ElementData[] = CATALOG.filter(
  (el) => el.atomicNumber <= PLAYABLE_MAX_Z,
);

// ── Cálculos de fórmula ─────────────────────────────────────────────────────

export type ComponentMap = Record<string, number>;

/** "H2O" -> { H: 1, O: 1 } */
export function parseFormula(formula: string): ComponentMap {
  const map: ComponentMap = {};
  const regex = /([A-Z][a-z]*)(\d*)/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(formula)) !== null) {
    map[match[1]] = (map[match[1]] ?? 0) + (parseInt(match[2], 10) || 1);
  }
  return map;
}

const ELEMENT_ORDER = CATALOG.map((el) => el.symbol);

/** Ordenação canônica determinística: elementos mais eletropositivos primeiro. */
export function canonicalOrder(a: string, b: string): number {
  const ia = ELEMENT_ORDER.indexOf(a);
  const ib = ELEMENT_ORDER.indexOf(b);
  if (ia !== -1 && ib !== -1) return ia - ib;
  if (ia !== -1) return -1;
  if (ib !== -1) return 1;
  return a.localeCompare(b);
}

/** { H: 2, O: 1 } -> "H2O" */
export function stringifyFormula(map: ComponentMap): string {
  return Object.keys(map)
    .sort(canonicalOrder)
    .map((k) => k + (map[k] > 1 ? map[k] : ""))
    .join("");
}

export function atomCount(formula: string): number {
  return Object.values(parseFormula(formula)).reduce((a, b) => a + b, 0);
}

export function molarMass(formula: string): number {
  return Object.entries(parseFormula(formula)).reduce(
    (sum, [sym, n]) => sum + (CATALOG_BY_SYMBOL[sym]?.atomicMass ?? 0) * n,
    0,
  );
}

/** Divide uma fórmula em tokens [símbolo, quantidade] em ordem canônica. */
export function formulaTokens(formula: string): Array<[string, number]> {
  const map = parseFormula(formula);
  return Object.keys(map)
    .sort(canonicalOrder)
    .map((sym) => [sym, map[sym]] as [string, number]);
}

// ── Ambiente da reação ──────────────────────────────────────────────────────

export interface Environment {
  temperature: number;
  pressure: number;
  catalyst: string;
  electricity: boolean;
  radiation: boolean;
}

// ── Alvos de síntese ────────────────────────────────────────────────────────

export interface Compound {
  formula: string;
  name: string;
  emoji: string;
  /** Dica educacional exibida quando o jogador pede ajuda. */
  hint: string;
  /** Covalente, iônica ou metálica — a ligação que o jogador deve declarar. */
  bond: "covalent" | "ionic" | "metallic";
  /** Condições ambientais sob as quais a síntese é permitida. */
  check: (env: Environment) => boolean;
}

export const COMPOUNDS: Compound[] = [
  {
    formula: "H2O", name: "Água", emoji: "💧", bond: "covalent",
    hint: "Hidrogênio e oxigênio compartilham elétrons. Aqueça acima de 100 °C ou use arco elétrico para iniciar a reação.",
    check: (e) => e.temperature >= 100 || e.electricity,
  },
  {
    formula: "O2", name: "Gás oxigênio", emoji: "🌬️", bond: "covalent",
    hint: "Apenas dois oxigênios unidos. Eletricidade, calor acima de 100 °C ou pressão acima de 5 atm resolvem.",
    check: (e) => e.electricity || e.temperature >= 100 || e.pressure >= 5,
  },
  {
    formula: "O3", name: "Ozônio", emoji: "🌩️", bond: "covalent",
    hint: "Três oxigênios. Uma descarga elétrica silenciosa é o jeito clássico de produzir ozônio.",
    check: (e) => e.electricity,
  },
  {
    formula: "CO2", name: "Dióxido de carbono", emoji: "🫧", bond: "covalent",
    hint: "O carbono queima no oxigênio. Leve a temperatura acima de 250 °C.",
    check: (e) => e.temperature >= 250,
  },
  {
    formula: "CO", name: "Monóxido de carbono", emoji: "☠️", bond: "covalent",
    hint: "Carbono com pouco oxigênio. Aqueça acima de 700 °C e baixe a pressão para 1 atm ou menos.",
    check: (e) => e.temperature >= 700 && e.pressure <= 1,
  },
  {
    formula: "NH3", name: "Amônia", emoji: "🧪", bond: "covalent",
    hint: "Processo Haber: nitrogênio com hidrogênio sob alta pressão (10 atm ou mais) e catalisador de ferro.",
    check: (e) => e.pressure >= 10 && e.catalyst === "Fe",
  },
  {
    formula: "HCl", name: "Cloreto de hidrogênio", emoji: "💨", bond: "covalent",
    hint: "Hidrogênio e cloro compartilham um par de elétrons. Aqueça acima de 200 °C ou use platina como catalisador.",
    check: (e) => e.temperature >= 200 || e.catalyst === "Pt",
  },
  {
    formula: "CH4", name: "Metano", emoji: "🔥", bond: "covalent",
    hint: "Um carbono ligado a quatro hidrogênios. Pressão acima de 5 atm e temperatura acima de 150 °C.",
    check: (e) => e.pressure > 5 && e.temperature > 150,
  },
  {
    formula: "NaCl", name: "Cloreto de sódio (sal de cozinha)", emoji: "🧂", bond: "ionic",
    hint: "O sódio entrega seu elétron ao cloro — a ligação iônica clássica. Forma-se facilmente à temperatura ambiente.",
    check: (e) => e.temperature >= 25,
  },
  {
    formula: "Fe2O3", name: "Óxido de ferro (III)", emoji: "🟤", bond: "ionic",
    hint: "Ferrugem! Ferro e oxigênio. Aqueça acima de 50 °C e deixe a radiação acelerar a corrosão.",
    check: (e) => e.temperature >= 50 && e.radiation,
  },
  {
    formula: "MgO", name: "Óxido de magnésio", emoji: "✨", bond: "ionic",
    hint: "O magnésio queima com brilho intenso no oxigênio. Deixe a câmara acima de 600 °C.",
    check: (e) => e.temperature >= 600,
  },
  {
    formula: "CaO", name: "Óxido de cálcio", emoji: "🪨", bond: "ionic",
    hint: "Cal virgem. Asse o calcário quente o suficiente — acima de 800 °C.",
    check: (e) => e.temperature >= 800,
  },
  {
    formula: "Li2O", name: "Óxido de lítio", emoji: "⚪", bond: "ionic",
    hint: "Lítio e oxigênio. A câmara precisa de pelo menos 450 °C.",
    check: (e) => e.temperature >= 450,
  },
  {
    formula: "K2O", name: "Óxido de potássio", emoji: "🌾", bond: "ionic",
    hint: "Potássio e oxigênio. Mantenha acima de 350 °C.",
    check: (e) => e.temperature >= 350,
  },
  {
    formula: "Al2O3", name: "Óxido de alumínio", emoji: "💎", bond: "ionic",
    hint: "Alumina. Eletrólise mais calor acima de 900 °C — igual ao processo Hall–Héroult.",
    check: (e) => e.electricity && e.temperature >= 900,
  },
  {
    formula: "ZnO", name: "Óxido de zinco", emoji: "⚪", bond: "ionic",
    hint: "Zinco e oxigênio acima de 500 °C, com corrente elétrica para conduzir a reação.",
    check: (e) => e.temperature >= 500 && e.electricity,
  },
  {
    formula: "PbS", name: "Sulfeto de chumbo (II)", emoji: "⚫", bond: "ionic",
    hint: "Galena, o minério do chumbo. Funde chumbo com enxofre acima de 600 °C.",
    check: (e) => e.temperature >= 600,
  },
  {
    formula: "FeS2", name: "Sulfeto de ferro (pirita)", emoji: "🌟", bond: "ionic",
    hint: "Ouro dos tolos. Ferro e enxofre a 400 °C sob pelo menos 5 atm.",
    check: (e) => e.temperature >= 400 && e.pressure >= 5,
  },
  {
    formula: "AgCl", name: "Cloreto de prata", emoji: "📷", bond: "ionic",
    hint: "Química da fotografia: prata e cloro reagem sob radiação.",
    check: (e) => e.radiation,
  },
  {
    formula: "CaCO3", name: "Carbonato de cálcio", emoji: "🐚", bond: "ionic",
    hint: "Calcário e giz. Cálcio, carbono e oxigênio sob pressão acima de 25 atm.",
    check: (e) => e.pressure >= 25,
  },
  {
    formula: "Na2CO3", name: "Carbonato de sódio", emoji: "🧴", bond: "ionic",
    hint: "Barrilha. Sódio, carbono e oxigênio aquecidos acima de 800 °C.",
    check: (e) => e.temperature >= 800,
  },
  {
    formula: "CuSO4", name: "Sulfato de cobre (II)", emoji: "🔵", bond: "ionic",
    hint: "O famoso cristal azul. Pressão acima de 10 atm e temperatura acima de 150 °C.",
    check: (e) => e.pressure >= 10 && e.temperature >= 150,
  },
  {
    formula: "BaSO4", name: "Sulfato de bário", emoji: "🩻", bond: "ionic",
    hint: "O contraste de raios-X. Pressão acima de 20 atm mais uma fonte de radiação.",
    check: (e) => e.pressure >= 20 && e.radiation,
  },
  {
    formula: "SiO2", name: "Dióxido de silício", emoji: "🏖️", bond: "covalent",
    hint: "Areia, vidro, quartzo. Funde silício e oxigênio acima de 1200 °C.",
    check: (e) => e.temperature >= 1200,
  },
  {
    formula: "H2O2", name: "Peróxido de hidrogênio", emoji: "🫙", bond: "covalent",
    hint: "Dois hidrogênios, dois oxigênios. Comprima a câmara a 20 atm ou mais.",
    check: (e) => e.pressure >= 20,
  },
  {
    formula: "NO2", name: "Dióxido de nitrogênio", emoji: "🟠", bond: "covalent",
    hint: "O gás marrom. Nitrogênio e oxigênio a 500 °C ou mais.",
    check: (e) => e.temperature >= 500,
  },
  {
    formula: "SO2", name: "Dióxido de enxofre", emoji: "🌋", bond: "covalent",
    hint: "Gás vulcânico. Queime enxofre no oxigênio acima de 300 °C.",
    check: (e) => e.temperature >= 300,
  },
  {
    formula: "SO3", name: "Trióxido de enxofre", emoji: "🏭", bond: "covalent",
    hint: "O processo de contato exige catalisador de platina — só temperatura não basta.",
    check: (e) => e.catalyst === "Pt",
  },
  {
    formula: "H2SO4", name: "Ácido sulfúrico", emoji: "⚗️", bond: "covalent",
    hint: "O rei dos ácidos. Pressão acima de 15 atm com catalisador de platina.",
    check: (e) => e.pressure >= 15 && e.catalyst === "Pt",
  },
  {
    formula: "HNO3", name: "Ácido nítrico", emoji: "🧫", bond: "covalent",
    hint: "Processo Ostwald: catalisador de platina e câmara acima de 200 °C.",
    check: (e) => e.catalyst === "Pt" && e.temperature >= 200,
  },
  {
    formula: "C2H2", name: "Acetileno", emoji: "🔥", bond: "covalent",
    hint: "Uma ligação tripla carbono–carbono. Provoque um arco elétrico para sintetizá-lo.",
    check: (e) => e.electricity,
  },
  {
    formula: "C6H6", name: "Benzeno", emoji: "⬡", bond: "covalent",
    hint: "O anel aromático. 40 atm de pressão e 400 °C.",
    check: (e) => e.pressure >= 40 && e.temperature >= 400,
  },
  {
    formula: "CH3OH", name: "Metanol", emoji: "🧪", bond: "covalent",
    hint: "Álcool de madeira. Catalisador de níquel sob 50 atm de pressão.",
    check: (e) => e.pressure >= 50 && e.catalyst === "Ni",
  },
  {
    formula: "C2H5OH", name: "Etanol", emoji: "🍷", bond: "covalent",
    hint: "O álcool de bebidas, sintético. 300 °C e 60 atm.",
    check: (e) => e.temperature >= 300 && e.pressure >= 60,
  },
  {
    formula: "C3H8", name: "Propano", emoji: "🛢️", bond: "covalent",
    hint: "Três carbonos, oito hidrogênios. 200 °C e 20 atm.",
    check: (e) => e.temperature >= 200 && e.pressure >= 20,
  },
  {
    formula: "C4H10", name: "Butano", emoji: "🕯️", bond: "covalent",
    hint: "Gás de isqueiro. 250 °C e 25 atm.",
    check: (e) => e.temperature >= 250 && e.pressure >= 25,
  },
  {
    formula: "HCN", name: "Cianeto de hidrogênio", emoji: "⚠️", bond: "covalent",
    hint: "Manuseie com cuidado. Catalisador de platina e 1000 °C escaldantes.",
    check: (e) => e.catalyst === "Pt" && e.temperature >= 1000,
  },
  {
    formula: "PCl3", name: "Tricloreto de fósforo", emoji: "🟢", bond: "covalent",
    hint: "Fósforo encontra cloro sob radiação.",
    check: (e) => e.radiation,
  },
  {
    formula: "SF6", name: "Hexafluoreto de enxofre", emoji: "🎈", bond: "covalent",
    hint: "O gás da voz grave. Enxofre e flúor sob 30 atm de pressão.",
    check: (e) => e.pressure >= 30,
  },
  {
    formula: "CS2", name: "Dissulfeto de carbono", emoji: "🟡", bond: "covalent",
    hint: "Carbono e enxofre a 900 °C.",
    check: (e) => e.temperature >= 900,
  },
  {
    formula: "NI3", name: "Triiodeto de nitrogênio", emoji: "💥", bond: "covalent",
    hint: "O explosivo que odeia ser tocado. Só permanece estável abaixo de 0 °C.",
    check: (e) => e.temperature <= 0,
  },
  {
    formula: "AuPt", name: "Liga de ouro e platina", emoji: "🥇", bond: "metallic",
    hint: "Uma ligação metálica: ambos os átomos põem seus elétrons num mar comum. Eletricidade mais 50 atm de pressão.",
    check: (e) => e.electricity && e.pressure > 50,
  },
  {
    formula: "FePt3", name: "Liga de ferro e platina", emoji: "🥈", bond: "metallic",
    hint: "Uma liga magnética. Derreta ferro e platina a 800 °C sob 20 atm.",
    check: (e) => e.temperature >= 800 && e.pressure > 20,
  },
];

export const COMPOUND_BY_FORMULA: Record<string, Compound> = Object.fromEntries(
  COMPOUNDS.map((c) => [stringifyFormula(parseFormula(c.formula)), c]),
);

/** Índice pseudoaleatório a partir de uma data (o desafio diário). */
export function dailyCompoundIndex(date: Date): number {
  const seed = date.getFullYear() * 10000 + (date.getMonth() + 1) * 100 + date.getDate();
  return seed % COMPOUNDS.length;
}

/** Escolhe um composto diferente do atual. */
export function randomCompoundIndex(exclude?: number): number {
  let index = Math.floor(Math.random() * COMPOUNDS.length);
  if (exclude !== undefined && COMPOUNDS.length > 1) {
    while (index === exclude) {
      index = Math.floor(Math.random() * COMPOUNDS.length);
    }
  }
  return index;
}

// ── Educação sobre tipos de ligação ────────────────────────────────────────

export type BondType = "covalent" | "ionic" | "metallic";

export const BOND_LABELS: Record<BondType, string> = {
  covalent: "Covalente",
  ionic: "Iônica",
  metallic: "Metálica",
};

/**
 * Mensagem educacional exibida quando o jogador erra o tipo de ligação.
 * Constrói a frase a partir dos elementos presentes no composto.
 */
export function bondMistakeMessage(compound: Compound, chosen: BondType): string {
  const kinds = new Set(
    formulaTokens(compound.formula).map(([sym]) => {
      const cat = CATALOG_BY_SYMBOL[sym]?.category;
      if (cat === "noble") return "noble";
      if (cat === "nonmetal" || cat === "halogen" || cat === "metalloid" || cat === "hydrogen")
        return "nonmetal";
      return "metal";
    }),
  );

  if (kinds.has("metal") && kinds.has("nonmetal")) {
    return "Lembre-se: um metal + um não metal geralmente formam uma ligação iônica — os elétrons são transferidos de um átomo para o outro. Não é uma ligação " + BOND_LABELS[chosen].toLowerCase() + ".";
  }
  if (kinds.has("metal") && kinds.size === 1) {
    return "Lembre-se: átomos metálicos compartilham um mar de elétrons deslocalizados — isso é uma ligação metálica. Não é uma ligação " + BOND_LABELS[chosen].toLowerCase() + ".";
  }
  if (chosen === "metallic") {
    return "Lembre-se: apenas átomos metálicos formam ligações metálicas. Não metais compartilham pares de elétrons — este é um composto covalente.";
  }
  return "Lembre-se: átomos de não metais compartilham pares de elétrons — isso é uma ligação covalente. Não é uma ligação " + BOND_LABELS[chosen].toLowerCase() + ".";
}

// ── Progressão ──────────────────────────────────────────────────────────────

export const BASE_XP_REQUIRED = 100;
export const DAILY_CHALLENGE_BONUS = 50;

export function xpForCompound(formula: string, isDaily: boolean): number {
  return atomCount(formula) * 20 + (isDaily ? DAILY_CHALLENGE_BONUS : 0);
}

export function nextXpRequired(currentRequired: number): number {
  return Math.floor(currentRequired * 1.5);
}

// ── Motor de geometria (GPE e GM) ───────────────────────────────────────────
// Modelo educacional, não um pacote de química quântica: para uma fórmula ABₙ
// o átomo central é o menos eletronegativo (excluindo H), e o número estérico
// é a quantidade de átomos ligados mais os pares isolados do central.

export interface MolecularGeometry {
  /** Fórmula descrita, ex.: "NH3". */
  formula: string;
  central: string;
  /** Total de domínios eletrônicos ao redor do átomo central. */
  domains: number;
  bonded: number;
  lonePairs: number;
  /** Geometria dos Pares Eletrônicos — arranjo de TODOS os domínios. */
  gpe: string;
  /** Geometria Molecular — forma final visível. */
  gm: string;
  /** Texto especial para compostos iônicos/metálicos (retículo/nuvem). */
  lattice: string;
  angle: string;
  /** Chave de forma usada pelo visualizador 3D. */
  shapeKey: string;
  /** Verdadeiro quando é diatômica/homonuclear sem "átomo central" real. */
  noCenter?: boolean;
}

const GPE_NAMES: Record<number, string> = {
  2: "Linear",
  3: "Trigonal plana",
  4: "Tetraédrica",
  5: "Bipirâmide trigonal",
  6: "Octaédrica",
};

const GM_NAMES: Record<string, string> = {
  "2-0": "Linear",
  "3-0": "Trigonal plana",
  "2-1": "Angular (dobrada)",
  "4-0": "Tetraédrica",
  "3-1": "Pirâmide trigonal",
  "2-2": "Angular (dobrada)",
  "5-0": "Bipirâmide trigonal",
  "4-1": "Balancim (seesaw)",
  "6-0": "Octaédrica",
  "5-1": "Pirâmide de base quadrada",
  "4-2": "Planar quadrada",
};

const ANGLES: Record<string, string> = {
  "2-0": "180°",
  "3-0": "120°",
  "2-1": "≈120° (um pouco menos)",
  "4-0": "109,5°",
  "3-1": "≈107° (um pouco menos)",
  "2-2": "≈104,5° (água)",
  "5-0": "90° / 120° / 180°",
  "4-1": "≈90° / ≈120°",
  "6-0": "90° / 180°",
  "5-1": "≈90°",
  "4-2": "90°",
};

const SHAPE_KEYS: Record<string, string> = {
  "2-0": "linear",
  "3-0": "trigonal-planar",
  "2-1": "bent",
  "4-0": "tetrahedral",
  "3-1": "trigonal-pyramidal",
  "2-2": "bent",
  "5-0": "trigonal-bipyramidal",
  "4-1": "seesaw",
  "6-0": "octahedral",
  "5-1": "square-pyramidal",
  "4-2": "square-planar",
};

/** Compostos com ligações especiais/irregulares — resolvidos explicitamente. */
const SPECIAL_GEOMETRIES: Record<string, (f: string) => MolecularGeometry> = {
  H2O: (f) => ({ formula: f, central: "O", domains: 4, bonded: 2, lonePairs: 2, gpe: GPE_NAMES[4], gm: GM_NAMES["2-2"], lattice: "", angle: ANGLES["2-2"], shapeKey: "bent" }),
  H2O2: (f) => ({ formula: f, central: "O", domains: 4, bonded: 2, lonePairs: 2, gpe: "Tetraédrica (por O)", gm: "Cadeia aberta (torcida)", lattice: "", angle: "≈94,8° diedro / ≈111° H-O-O", shapeKey: "chain" }),
  C2H2: (f) => ({ formula: f, central: "C", domains: 2, bonded: 1, lonePairs: 0, gpe: "Linear (por C)", gm: "Linear (HC≡CH)", lattice: "", angle: "180°", shapeKey: "linear-chain" }),
  C2H5OH: (f) => ({ formula: f, central: "C", domains: 4, bonded: 4, lonePairs: 0, gpe: "Tetraédrica (por C)", gm: "Cadeia tetraédrica", lattice: "", angle: "≈109,5°", shapeKey: "chain" }),
  CH3OH: (f) => ({ formula: f, central: "C", domains: 4, bonded: 4, lonePairs: 0, gpe: "Tetraédrica (por C)", gm: "Cadeia tetraédrica", lattice: "", angle: "≈109,5°", shapeKey: "chain" }),
  C3H8: (f) => ({ formula: f, central: "C", domains: 4, bonded: 4, lonePairs: 0, gpe: "Tetraédrica (por C)", gm: "Cadeia tetraédrica (propano)", lattice: "", angle: "≈109,5°", shapeKey: "chain" }),
  C4H10: (f) => ({ formula: f, central: "C", domains: 4, bonded: 4, lonePairs: 0, gpe: "Tetraédrica (por C)", gm: "Cadeia tetraédrica (butano)", lattice: "", angle: "≈109,5°", shapeKey: "chain" }),
  C6H6: (f) => ({ formula: f, central: "C", domains: 3, bonded: 2, lonePairs: 1, gpe: "Trigonal plana (por C)", gm: "Hexágono planar (anel aromático)", lattice: "", angle: "120°", shapeKey: "hexagon" }),
  O3: (f) => ({ formula: f, central: "O", domains: 3, bonded: 2, lonePairs: 1, gpe: GPE_NAMES[3], gm: GM_NAMES["2-1"], lattice: "", angle: "≈117° (ressonância)", shapeKey: "bent" }),
  SO2: (f) => ({ formula: f, central: "S", domains: 3, bonded: 2, lonePairs: 1, gpe: GPE_NAMES[3], gm: GM_NAMES["2-1"], lattice: "", angle: "≈119°", shapeKey: "bent" }),
  CO2: (f) => ({ formula: f, central: "C", domains: 2, bonded: 2, lonePairs: 0, gpe: GPE_NAMES[2], gm: GM_NAMES["2-0"], lattice: "", angle: "180° (ligações duplas)", shapeKey: "linear" }),
  CS2: (f) => ({ formula: f, central: "C", domains: 2, bonded: 2, lonePairs: 0, gpe: GPE_NAMES[2], gm: GM_NAMES["2-0"], lattice: "", angle: "180° (ligações duplas)", shapeKey: "linear" }),
  SiO2: (f) => ({ formula: f, central: "Si", domains: 2, bonded: 2, lonePairs: 0, gpe: GPE_NAMES[2], gm: "Linear (O=Si=O)", lattice: "", angle: "180°", shapeKey: "linear" }),
  HCN: (f) => ({ formula: f, central: "C", domains: 2, bonded: 2, lonePairs: 0, gpe: GPE_NAMES[2], gm: "Linear (H-C≡N)", lattice: "", angle: "180°", shapeKey: "linear" }),
  H2SO4: (f) => ({ formula: f, central: "S", domains: 4, bonded: 4, lonePairs: 0, gpe: "Tetraédrica (por S)", gm: "Tetraédrica (S central)", lattice: "", angle: "≈109,5°", shapeKey: "tetrahedral" }),
  HNO3: (f) => ({ formula: f, central: "N", domains: 3, bonded: 3, lonePairs: 0, gpe: "Trigonal plana (por N)", gm: "Trigonal plana (N central)", lattice: "", angle: "120°", shapeKey: "trigonal-planar" }),
  NI3: (f) => ({ formula: f, central: "N", domains: 4, bonded: 3, lonePairs: 1, gpe: GPE_NAMES[4], gm: GM_NAMES["3-1"], lattice: "", angle: "≈107° (átomos de I enormes!)", shapeKey: "trigonal-pyramidal" }),
};

/** Não metais, usados para escolher o átomo central menos eletronegativo. */
const NONMETALS = new Set([
  "H", "B", "C", "N", "O", "F", "Si", "P", "S", "Cl", "As", "Se", "Br", "I", "Xe",
]);

/**
 * Calcula GPE / GM (ou notas de retículo cristalino / nuvem de elétrons).
 * Pura e síncrona — segura para chamar durante o render.
 */
export function molecularGeometry(formula: string, bond: BondType): MolecularGeometry {
  const norm = stringifyFormula(parseFormula(formula));

  if (bond === "ionic") {
    return {
      formula: norm, central: "—", domains: 0, bonded: 0, lonePairs: 0,
      gpe: "Não se aplica", gm: "Não se aplica",
      lattice: "Compostos iônicos formam um retículo cristalino: uma grade rígida tridimensional de cátions e ânions alternados, mantidos juntos por atração eletrostática. Não existe uma molécula isolada — cada íon é cercado por vizinhos de carga oposta.",
      angle: "—", shapeKey: "lattice",
    };
  }
  if (bond === "metallic") {
    return {
      formula: norm, central: "—", domains: 0, bonded: 0, lonePairs: 0,
      gpe: "Não se aplica", gm: "Não se aplica",
      lattice: "Ligas metálicas são mantidas pela ligação metálica: os cátions ficam empacotados num retículo enquanto os elétrons de valência deslocalizados formam um 'mar' que flui livremente — daí a condutividade e a maleabilidade.",
      angle: "—", shapeKey: "electron-sea",
    };
  }

  const special = SPECIAL_GEOMETRIES[norm];
  if (special) return special(norm);

  const tokens = formulaTokens(norm);
  if (atomCount(norm) === 2) {
    // Molécula diatômica (homo ou heteronuclear): linear, sem átomo central real.
    return {
      formula: norm, central: tokens[0][0], domains: 0, bonded: 1, lonePairs: 0,
      gpe: "Linear", gm: "Linear (diatômica)",
      lattice: "", angle: "180°", shapeKey: "diatomic", noCenter: true,
    };
  }

  // Escolhe o átomo central: prefere não metais, depois o token mais raro.
  const nonmetalTokens = tokens.filter(([sym]) => NONMETALS.has(sym) && sym !== "H");
  const candidates = nonmetalTokens.length > 0 ? nonmetalTokens : tokens;
  const [central] = candidates.reduce((a, b) => (a[1] <= b[1] ? a : b));

  const bonded = tokens
    .filter(([sym]) => sym !== central)
    .reduce((sum, [, n]) => sum + n, 0);
  const lonePairs = lonePairsFor(central, bonded);
  const domains = bonded + lonePairs;

  const key = `${domains}-${lonePairs}`;
  return {
    formula: norm,
    central,
    domains,
    bonded,
    lonePairs,
    gpe: GPE_NAMES[domains] ?? `${domains} domínios`,
    gm: GM_NAMES[key] ?? "Irregular",
    lattice: "",
    angle: ANGLES[key] ?? "—",
    shapeKey: SHAPE_KEYS[key] ?? "linear",
  };
}

/**
 * Estimativa educacional de pares isolados: os elétrons de valência
 * restantes do átomo central após formar ligações simples, divididos por 2.
 * Suficiente para as fórmulas do laboratório (ligações duplas ficam nas
 * exceções de SPECIAL_GEOMETRIES).
 */
function lonePairsFor(central: string, bonded: number): number {
  const VALENCE_ELECTRONS: Record<string, number> = {
    B: 3, C: 4, N: 5, O: 6, F: 7, Si: 4, P: 5, S: 6, Cl: 7, As: 5, Se: 6, Br: 7, I: 7,
  };
  const valence = VALENCE_ELECTRONS[central];
  if (valence === undefined) return 0;
  return Math.max(0, Math.floor((valence - bonded) / 2));
}

/**
 * Deduz o tipo de ligação mais provável a partir das categorias dos
 * elementos: metal + não metal → iônica; só metais → metálica; caso
 * contrário → covalente. Usado no modo livre para dar feedback.
 */
export function guessBondType(formula: string): BondType {
  const tokens = formulaTokens(formula);
  let hasMetal = false;
  let hasNonmetal = false;
  for (const [sym] of tokens) {
    const cat = CATALOG_BY_SYMBOL[sym]?.category;
    if (
      cat === "nonmetal" || cat === "halogen" || cat === "metalloid" ||
      cat === "noble" || cat === "hydrogen"
    ) {
      hasNonmetal = true;
    } else {
      hasMetal = true;
    }
  }
  if (hasMetal && hasNonmetal) return "ionic";
  if (hasMetal && !hasNonmetal) return "metallic";
  return "covalent";
}
